"""Independent complete lower-rho B1 through B5 composition; consumes full fresh arithmetic receipts."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from copy import deepcopy
import importlib.util,json,sys
H=Path(__file__).resolve().parent;ROOT=H.parents[2];BASE=ROOT/'work/cutoff25_20261011';LOW=BASE/'new_root';RUNS=ROOT/'runs/cutoff25_20261011/root'
B=None;RHO_LO=None;RHO_HI=None;PROFILE=None;SELECTION=None
I=R=L=C=None;PANEL=None;CHOICE=None;REVIEW_MAPPING=None
PYTHON='/Users/bkolodziejek/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
spec=importlib.util.spec_from_file_location('scalar_composition',H/'compose_middle_b5_exact_v2.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
need,bind,read,same,enc,dec,guard,mean_floor=s.need,s.bind,s.read,s.same,s.enc,s.dec,s.guard,s.mean_floor
BANDS={1:('11/10','6/5','13/5','434477/1000000'),2:('6/5','13/10','29/10','434477/1000000'),3:('13/10','7/5','31/10','434477/1000000'),4:('7/5','3/2','33/10','3037969/7000000'),5:('3/2','33/20','18/5','1068023/2500000')}
def configure(b):
 global B,RHO_LO,RHO_HI,PROFILE,I,R,L
 need(type(b)is int and b in BANDS,'literal lower branch1 through5');B=b;lo,hi,r,cap=BANDS[B];RHO_LO,RHO_HI=F(lo),F(hi)
 PROFILE=dict(n=25,nmax=25,radius=r,radius_minus=r,radius_plus=r,cap=cap,barrier='0',grid=[24,24,8,4],invariants=dict(rho_lo=lo,rho=hi))
 I=LOW/f'initial25_b{B}_exact_v1';R=LOW/f'resource25_b{B}_v1';L=LOW/f'local25_b{B}_v2'
SL=F(3162277660,10**9);CACHE_SHA='95c9b510c8a40e3e73e782c67d98ce0f29ea09ce689f4f3e993ad3580ca5d15d'
def frozen(d):
 z=read(d/'FROZEN_SOURCES.json')
 for n,h in z.items():bind(d/n,h)
 return z

def coverage(z):
 need(type(z['total'])is int and z['total']==18432 and type(z['active'])is int and type(z['excluded'])is int,'typed complete full signed cover')
 need(z['active']+z['excluded']==18432 and sum(z['reasons'].values())==z['excluded'],'complete signed rectangle accounting')
 need(len(z['panels'])==100 and all(x['pl']==str(F(i,100)) and x['pu']==str(F(i+1,100))for i,x in enumerate(z['panels'])),'all100 closed p panels')

def receipt(d,pname,aname,checker,status,mapping):
 p,a=read(d/pname),read(d/aname)
 need(a['status']==status and a['proof_sha256']==bind(d/pname) and a['checker_sha256']==bind(d/checker),'fresh selected proof and original checker')
 need(same(p['source_sha256'],mapping) and same(a['source_sha256'],mapping),'complete fixed exact runtime')
 need(len(a['negative_controls'])==len(set(a['negative_controls']))==12,'all12 distinct malformed object controls')
 need(same(a['profile'],PROFILE) and same(p['profile'],PROFILE),'literal unrestricted witness region profile')
 return p,a

def execution(label,d,program,args,mapping,parents=(),unbuffered=True):
 log=RUNS/label;e=read(log/'metadata.json')
 need(type(e['returncode'])is int and e['returncode']==0 and e['cwd']==str(d),'successful selected completed execution')
 commands=[[PYTHON,'-B']+switches+[program,*args]for switches in([[],['-u']]if unbuffered is None else[(['-u']if unbuffered else[])])]
 need(e['command']in commands,'literal ordinary exact execution command')
 bind(log/'stdout.txt',e['stdout_sha256']);bind(log/'stderr.txt',e['stderr_sha256'])
 for n,h in mapping.items():
  bind(d/n,h)
  if Path(n).suffix in('.py','.json','.tex'):need(e['input_sha256'].get(n)==h,'direct contemporaneous executable/structured source input')
  else:
   candidates=['FROZEN_SOURCES.json','KERNEL_COPY_MANIFEST.json'];found=False
   for mn in candidates:
    if mn not in e['input_sha256']:continue
    bind(d/mn,e['input_sha256'][mn]);m=read(d/mn);m=m.get('files',m)
    if m.get(n)==h:found=True
   need(found,'omitted proof text pinned by actual logged source manifest')
 for n in parents:need(e['input_sha256'].get(n)==bind(d/n),'logged selected local candidate input')
 return e

def cache_account(record,keys,maxcalls):
 distinct=len(set(keys));calls=len(keys)
 need(calls<=maxcalls<128 and record['cache_before']==dict(hits=0,misses=0,size=0,maxsize=128),'fresh empty bounded exact cache')
 need(record['cache_after']==dict(hits=calls-distinct,misses=distinct,size=distinct,maxsize=128),'independent complete argument multiplicity')
 need(record['mathematical_cover_calls']==calls and record['full_stage_evaluations']==distinct and record['memoized_calls']==calls-distinct,'covers distinct from executed stages')
 return dict(covers=calls,full_stage_evaluations=distinct,memoized_calls=calls-distinct)

def next_profile(p,old,res):
 need(res['excluded']is False,'same-law surviving preceding resource');p=deepcopy(p);r,physical=res['raw_row'],res['result'];p['p_interval']=[F(PANEL,100),F(PANEL+1,100)]
 need(all(x['pl']==F(PANEL,100)and x['pu']==F(PANEL+1,100)for x in(r,physical,old,res['initial'])),'same literal physical sign probability')
 for k in('radius_minus','radius_plus'):need(0<physical[k]<=p[k],'nested physical supports');p[k]=physical[k]
 p['radius']=max(F(23,10),p['radius_minus'],p['radius_plus']);v=p['invariants'];need(r['rho_lo']==v['rho_lo']==RHO_LO,'literal rho floor')
 v['rho']=min(v['rho'],r['rho'],old['rho'])
 for k in('M','eta','gamma_hi','mean_hi'):
  vals=[x[k]for x in(r,old,res['initial'])if k in x]
  if vals:v[k]=min(vals+[v[k]]if k in v else vals)
 for k in('gamma_lo','beta_lo','mean_lo'):
  vals=[x[k]for x in(r,old,res['initial'])if k in x]
  if vals:v[k]=max(vals+[v[k]]if k in v else vals)
 v['beta_hi']=min(v.get('beta_hi',F(1)),r['beta_hi_signed'],old['beta']);retained=v['mean_lo'];v['mean_lo']=mean_floor(r['pl'],r['pu'],r['theta'],retained)
 floor=dict(pl=r['pl'],pu=r['pu'],theta_upper=r['theta'],retained_lower=retained,grid=10**12,mean_lower=v['mean_lo'])
 need(v['rho_lo']<=v['rho']and v['beta_lo']<=v['beta_hi']and 0<v['mean_lo']<=v['mean_hi'],'ordered acquired moments')
 return p,floor

def merge(z,old,res,p):
 row=dict(dec(z['panels'][PANEL]),rho_lo=RHO_LO,rho_branch_upper=RHO_HI)
 for extra in(old,res['initial'],res['raw_row']):
  need(extra['pl']==row['pl']and extra['pu']==row['pu'],'same-law intersection domain')
  for k in('raw','D','theta','rho','beta','M','eta','H','gamma_hi','mean_hi'):
   if k in row and k in extra:row[k]=min(row[k],extra[k])
  for k in('A','B','beta_lo','gamma_lo','mean_lo'):
   if k in row and k in extra:row[k]=max(row[k],extra[k])
 row['mean_lo']=max(row['mean_lo'],p['invariants']['mean_lo']);return row

def support_inventory(obj,path):
 found=[]
 def walk(x,where):
  if isinstance(x,dict):
   structural=all(k in x for k in('gaussian','ray_rows','radius','rho_upper','beta_interval'))
   if isinstance(x.get('schema'),str)and 'SUPPORT'in x['schema']:need(structural,'recognized exact support schema')
   if structural:
    need(type(x['n'])is int and x['n']==25 and F(x['K'])==0 and F(x.get('q_contact',x.get('q')))==F(5,16),'actual index and acquired predecessor allowance')
    sign=x['support_sign'];need(type(sign)is int and sign in(-1,0,1),'typed full support ray selector')
    need([r['sign']for r in x['ray_rows']]==([-1,1]if sign==0 else[sign]),'complete declared support rays')
    for ray in x['ray_rows']:need(all(F(ray[k])<0 for k in('coefficient_at_R','contact_derivative_at_R','contact_derivative_slope_at_R','contact_upper')),'strict full-ray support certificate')
    found.append(dict(path=where,sha256=s.canonical(x),gaussian_cells=x['gaussian']['cells']))
   for k,v in x.items():walk(v,where+'/'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,where+'/'+str(i))
 walk(obj,path);return found

def physical(res,cfg,km,inv=None):
 # All intersections concern the same unrestricted attained witness and p.
 rr,seed=res['raw_row'],res['initial'];pl,pu=rr['pl'],rr['pu'];tl,tu=map(F,cfg['p'])
 need(pl==F(PANEL,100)and pu==F(PANEL+1,100)and pl<=tl<tu<=pu and all(x['pl']==pl and x['pu']==pu for x in(seed,res['result'])),'same physical panel and closed target subinterval')
 result=deepcopy(res['result']);result['rho_hi']=min(result['rho_hi'],RHO_HI);result['pl'],result['pu']=tl,tu;mappings=s.resource_interface(result,cfg)
 extra={}
 if 'acquired_theta_upper' in cfg:
  need(type(cfg['acquired_theta_upper'])is str and 0<=rr['theta']<=F(cfg['acquired_theta_upper'])<1,'acquired additional physical theta premise')
  need(km.get('theta_variance.py')==bind(BASE/'new_root/theta_variance.py'),'selected reviewed theta helper')
  review=read(H/'THETA_VARIANCE_SOURCE_REVIEW.json')
  need(review['status']=='PASS_INDEPENDENT_THETA_VARIANCE_DERIVATION_AND_SOURCE_REVIEW','independent theta helper review')
  for name,h in review['files_sha256'].items():bind(ROOT/name,h)
  extra['theta_upper']=dict(actual=str(rr['theta']),target=cfg['acquired_theta_upper'])
 sign=cfg['sign_premise'];need(sign['schema']=='ACTUAL_SIGN_CONDITIONED_MARGINAL_V1'and sign['conditional_means_zero']is True,'actual centered sign-conditioned marginals')
 endpoints={name:max(rr[k],seed[k])for name,k in [('negative_endpoint_lower','A'),('positive_endpoint_lower','B')]}
 for name,value in endpoints.items():need(0<F(sign[name])<=value,'acquired physical endpoint floor')
 if inv is None:
  beta=[max(rr['beta_lo'],seed['beta_lo']),min(rr['beta_hi_signed'],seed['beta'])]
  mean=[mean_floor(pl,pu,rr['theta'],max(seed['mean_lo'],rr.get('mean_lo',seed['mean_lo']))),min(seed['mean_hi'],rr['mean_hi'])]
 else:
  beta=[max(inv['beta_lo'],rr['beta_lo'],seed['beta_lo']),min(inv['beta_hi'],rr['beta_hi_signed'],seed['beta'])]
  mean=[mean_floor(pl,pu,rr['theta'],max(inv['mean_lo'],seed['mean_lo'])),min(inv['mean_hi'],seed['mean_hi'],rr['mean_hi'])]
 need(F(cfg['acquired_beta'][0])<=beta[0]<=beta[1]<=F(cfg['acquired_beta'][1]) and F(cfg['acquired_mean'][0])<=mean[0]<=mean[1]<=F(cfg['acquired_mean'][1]),'entire actual signed beta and mean ranges acquired')
 return beta,mean,endpoints,mappings,extra

def calculate():
 global C
 mode=CHOICE['mode'];need(mode in('local','global_count'),'explicit reviewed acquisition route')
 im,rm=frozen(I),frozen(R);lm=frozen(L)if mode=='local'else None;rmap=dict(rm,**{'FROZEN_SOURCES.json':bind(R/'FROZEN_SOURCES.json')})
 ip,ia=receipt(I,f'INITIAL25_B{B}_PROOF.json',f'INITIAL25_B{B}_ACCEPTED.json',f'initial25_b{B}.py',f'PASS_FRESH_EXACT_INITIAL25_B{B}',im)
 gp,ga=receipt(R,f'RESOURCE_B{B}_GLOBAL_PROOF.json',f'RESOURCE_B{B}_GLOBAL_ACCEPTED.json',f'resources_b{B}.py',f'PASS_FRESH_EXACT_SHARP25_B{B}_GLOBAL_RESOURCES',rmap)
 pred=read(I/'STRONGER24_COMPLETE_JOINED.json');need(ip['predecessor_sha256']==bind(I/'STRONGER24_COMPLETE_JOINED.json')=='f3c6a95c5fa814cc024872c0b4212d7d5272d8b7696306dfc0f5a3b74d12167f','audited stronger24 dependency')
 need(pred['status']=='PASS_FULL_STRONGER24_AUXILIARY_BOUND_IN_RETAINED_FRAMEWORK'and pred['conclusion']=='C24 < CE + 1/80','precise retained global predecessor theorem')
 need(F(ip['support']['q'])==25*F(1,80)==F(5,16) and F(ip['support']['smoothing_upper'])<F(434477,1000000)and F(ip['support']['owncap'])==F(PROFILE['cap'])==min(F(434477,1000000),F('.469'),F('.3322')*(1+F('.429')/RHO_LO),F('.3031')*(1+F('.646')/RHO_LO)),'smoothing owncap and same-law contact allowance')
 need(ip['maximum_covers']==12 and len(ip['stages'])==12,'finite unseeded INITIAL schedule');raw=d=None
 for stage in ip['stages']:
  need(stage['input_raw']==raw and stage['input_D']==d,'exact acquired global input guards');coverage(stage['cover']);nr,nd=guard(stage['cover']['R']),guard(stage['cover']['D'])
  if raw is not None:nr,nd=min(nr,F(raw)),min(nd,F(d))
  need(0<nr<10 and 0<nd<6 and F(stage['next_raw'])==nr and F(stage['next_D'])==nd,'valid exact outward feedback');raw,d=stage['next_raw'],stage['next_D']
 need(ip['final_invariants']==dict(raw=raw,D=d) and F(d)<(SL-1)*RHO_LO,'positive-gap final export guards');coverage(ip['export'])
 need(ia['signed_rectangles']==13*18432 and ia['probability_panels']==100 and same(ia['final_invariants'],ip['final_invariants']),'complete initial acceptance accounting')
 need(gp['parent_proof_sha256']==ga['parent_proof_sha256']==bind(I/f'INITIAL25_B{B}_PROOF.json') and gp['parent_acceptance_sha256']==ga['parent_acceptance_sha256']==bind(I/f'INITIAL25_B{B}_ACCEPTED.json'),'fresh exact global parent edges')
 need(gp['parent_manifest_sha256']==bind(I/'FROZEN_SOURCES.json') and same(gp['parent_source_sha256'],im),'global parent full source closure')
 need(len(gp['rows'])==ga['probability_panels']==100 and all(type(x['index'])is int and x['index']==i and type(x['result']['excluded'])is bool for i,x in enumerate(gp['rows'])),'global complete ordered actual outcome cover')
 need(ga['surviving_panels']==[x['index']for x in gp['rows']if not x['result']['excluded']] and ga['excluded_panels']==[x['index']for x in gp['rows']if x['result']['excluded']],'complete typed global resource receipt')
 for panel in ip['export']['panels']:need(F(panel['rho_lo'])==RHO_LO and F(panel['rho_branch_upper'])==RHO_HI,'literal branch survives export')
 res=dec(gp['rows'][PANEL]['result']);old=dec(ip['export']['panels'][PANEL]);p=dec(PROFILE);covers=0;floors=[];lp=None
 need(res['excluded']is False,'selected global survivor')
 entry=dict(excluded=False)
 if mode=='local':
  lp,la=receipt(L,f'PANEL_{PANEL}_PROOF.json',f'PANEL_{PANEL}_ACCEPTED.json',f'mixed_b{B}.py',f'PASS_FRESH_EXACT_SHARP25_B{B}_FOUR_COVER_PANEL',lm)
  need(lp['panel']==la['panel']==PANEL and len(lp['rows'])==1 and lp['rows'][0]['index']==PANEL and lp['maximum_covers_per_cycle']==lp['maximum_cycles']==4,'one actual finite local target')
  need(lp['initial_parent_sha256']==bind(I/f'INITIAL25_B{B}_PROOF.json') and lp['global_resource_parent_sha256']==bind(R/f'RESOURCE_B{B}_GLOBAL_PROOF.json'),'selected local parent proof edges')
  need(same(lp['parent_binding_sha256'],la['parent_binding_sha256']),'same local receipt complete parent binding')
  for n,h in lp['parent_binding_sha256'].items():bind(LOW/n,h)
  entry=lp['rows'][0]
  need(res['excluded']is False and type(entry['excluded'])is bool and 1<=len(entry['cycles'])<=4,'selected actual global survivor and finite local proof')
  for j,cycle in enumerate(entry['cycles']):
   need(type(cycle['cycle'])is int and cycle['cycle']==j+1,'ordered finite cycle');p,floor=next_profile(p,old,res)
   need(same(cycle['profile'],enc(p)) and same(cycle['theta_mean_floor'],enc(floor)),'independent acquired profile and mean floor');floors.append(enc(floor))
   raw,d=guard(res['raw_row']['raw']),guard(res['raw_row']['D']);need(1<=len(cycle['stages'])<=4,'bounded complete signed covers')
   for t,stage in enumerate(cycle['stages']):
    need(F(stage['input_raw'])==raw and F(stage['input_D'])==d and 0<raw<10 and 0<d<(SL-1)*p['invariants']['rho_lo'],'positive-gap acquired local guard');coverage(stage['cover']);z=stage['cover'];covers+=1
    if z['active']==0:
     need(t==len(cycle['stages'])-1 and j==len(entry['cycles'])-1 and z['R']==z['D']=='-1' and all(x['cells']==0 for x in z['panels']),'complete terminal empty signed cover')
    else:raw,d=min(raw,guard(z['R'])),min(d,guard(z['D']))
   if z['active']==0:
    need(cycle['excluded']is True and cycle['reason']=='complete local INITIAL cover empty' and 'resource'not in cycle,'explicit exact empty-cover exclusion')
   else:
    need(len(cycle['stages'])==4,'four nonempty covers precede resource acquisition')
    merged=merge(z,old,res,p);acq=cycle['resource'];need(same(acq['source'],enc(merged)) and acq['radius_minus']==str(p['radius_minus'])and acq['radius_plus']==str(p['radius_plus']),'same-law complete local resource input')
    plan=acq['plan'];need(type(plan)is list and len(plan)<=16,'bounded exact support plan');minus,plus=p['radius_minus'],p['radius_plus']
    for step in plan:
     need(set(step)=={'radius_minus','radius_plus'},'literal exact support plan');aa,bb=F(step['radius_minus']),F(step['radius_plus']);need(0<aa<=minus and 0<bb<=plus,'nested replay radii');minus,plus=aa,bb
    res=dec(acq['derivation']);need(type(res['excluded'])is bool and cycle['excluded']is res['excluded'],'same actual resource outcome')
    need(plan==[dict(radius_minus=x['radius_minus'],radius_plus=x['radius_plus'])for x in acq['derivation'].get('history',[])],'entire acquired support history bound')
    if res['excluded']:need(j==len(entry['cycles'])-1 and cycle['reason']==res['reason'],'explicit terminal resource exclusion')
    else:old=dec(z['panels'][PANEL])
   if j<len(entry['cycles'])-1:need(cycle['excluded']is False,'only same-law survivor continues')
  need(entry['excluded']is entry['cycles'][-1]['excluded'] and la['excluded']is entry['excluded'] and la['finite_local_cycles']==len(entry['cycles']) and la['local_signed_rectangles']==covers*18432 and la['probability_panels']==1,'complete final local output/receipt')
  if not entry['excluded']:need(len(entry['cycles'])==4 and same(entry['survivor_resource'],enc(res)),'full finite surviving resource')
  else:need('survivor_resource'not in entry,'excluded local output has no surviving resource')
 count_results=[]
 if not entry['excluded']:
  selected=CHOICE['counts'];need(type(selected)is list and 1<=len(selected)<=16,'finite selected complete count partition')
  last=F(PANEL,100)
  for choice in selected:
   C=(ROOT/choice['capsule']).resolve();need(C.is_relative_to(LOW),'selected exact count capsule')
   need(all(str((C/name).relative_to(ROOT))in REVIEW_MAPPING for name in('count_protocol.py','KERNEL_COPY_MANIFEST.json','contract.json')),'independent review pins actual selected count checker and target')
   contract=read(C/'contract.json');need(len(contract['rows'])==1,'one literal conditional count');cfg=contract['rows'][0];count=read(C/f'COUNT{PANEL}_ACCEPTED.json');forest=read(C/f'COUNT{PANEL}_FOREST.json');km=read(C/'KERNEL_COPY_MANIFEST.json')['files']
   tl,tu=map(F,cfg['p']);need(last==tl<tu<=F(PANEL+1,100),'ordered closed gap-free partition');last=tu
   need(type(cfg['n'])is int and cfg['n']==25 and type(cfg['index'])is int and cfg['index']==PANEL and cfg['K']=='0'and F(cfg['rho_lower'])==RHO_LO and F(cfg['rho_upper'])==RHO_HI,'literal actual count and rho domain')
   need(count['status']==f'PASS_FRESH_CONDITIONAL_EXACT_COUNT{PANEL}'and count['forest_sha256']==bind(C/f'COUNT{PANEL}_FOREST.json')and count['contract_sha256']==bind(C/'contract.json')and count['checker_sha256']==bind(C/'count_protocol.py'),'fresh count proof and correct actual receipt index')
   need(same(count['kernel_sha256'],km),'complete frozen count kernel')
   for name,h in km.items():bind(C/name,h)
   for key in('contract_sha256','checker_sha256','kernel_sha256'):need(same(forest[key],count[key]),'bound forest '+key)
   need(forest['schema']==choice['forest_schema']and type(forest['n'])is int and forest['n']==25 and type(forest['index'])is int and forest['index']==PANEL and len(forest['roots'])==26 and all(type(x['k'])is int and x['k']==k for k,x in enumerate(forest['roots'])),'complete actual26 count roots')
   need(F(forest['target'])==s.TARGET and F(count['statistics']['maximum_score'])<s.TARGET,'strict sharp-target comparison')
   need(count['statistics']['leaves']==count['fresh_leaf_evaluations']==sum(count['statistics']['closed_statuses'].values())and len(count['negative_controls'])==len(set(count['negative_controls']))==24,'complete fresh leaves and malformed controls')
   beta,mean,endpoints,mappings,extra=physical(res,cfg,km,p['invariants']if mode=='local'else None)
   # The constructor's EXACT_GLOBAL_INTERFACE is not independent acquisition.
   # Above we independently derive every numerical/physical count premise.
   if mode=='global_count':
    source_inputs=contract['source_inputs_sha256']
    for name,h in source_inputs.items():bind(ROOT/name,h)
    for pp in(R/f'RESOURCE_B{B}_GLOBAL_PROOF.json',R/f'RESOURCE_B{B}_GLOBAL_ACCEPTED.json'):
     need(source_inputs.get(str(pp.relative_to(ROOT)))==bind(pp),'selected global design has the actual exact parent')
   execution(ROOT/choice['accept_log'],C,'count_protocol.py',['accept'],dict(km,**{'count_protocol.py':bind(C/'count_protocol.py')}),['contract.json',f'COUNT{PANEL}_FOREST.json','KERNEL_COPY_MANIFEST.json'],unbuffered=None)
   need(same(read(ROOT/choice['accept_log']/'stdout.txt'),count),'logged full fresh count receipt')
   count_results.append(dict(capsule=choice['capsule'],p=cfg['p'],leaves=count['statistics']['leaves'],maximum_score=count['statistics']['maximum_score'],acquired_beta=enc(beta),acquired_mean=enc(mean),endpoints=enc(endpoints),additional_physical_premises=extra,quadratic_interfaces=mappings))
  need(last==F(PANEL+1,100),'complete original closed probability panel')
 # Fresh execution evidence. Imported sibling protocols are pinned by the
 # reviewed original drivers, their full receipts and cache sidecars; the
 # logger's local cwd snapshots are not misrepresented as sibling snapshots.
 cachecalls=[]
 for action in('construct','accept'):
  execution(ROOT/SELECTION[f'initial_{action}_log'],I,f'initial25_b{B}.py',[action],im,[f'INITIAL25_B{B}_PROOF.json']if action=='accept'else[],unbuffered=None)
 for action in('construct','accept'):
  execution(ROOT/SELECTION[f'global_{action}_log'],R,f'resources_b{B}.py',[action],rm,[f'RESOURCE_B{B}_GLOBAL_PROOF.json']if action=='accept'else[],unbuffered=None)
  if mode=='local':
   execution(ROOT/CHOICE[f'local_{action}_log'],L,f'mixed_b{B}_memoized.py',[action,str(PANEL)],lm,[f'PANEL_{PANEL}_PROOF.json']if action=='accept'else[],unbuffered=None)
   z=read(L/f'PANEL_{PANEL}_{action}_CACHE_RUNTIME.json');need(z['status']=='PASS_FRESH_LOW25_EXACT_LOCAL_CACHE'and type(z['index'])is int and z['index']==PANEL and z['action']==action and same(z['source_sha256'],lm),'same exact local cached protocol')
   bind(L/f'mixed_b{B}_memoized.py',z['wrapper_sha256']);bind(L/f'mixed_b{B}.py',z['original_checker_sha256']);bind(L/'exact_stage_cache.py',CACHE_SHA)
   expected={f'PANEL_{PANEL}_PROOF.json':bind(L/f'PANEL_{PANEL}_PROOF.json')}
   if action=='accept':expected[f'PANEL_{PANEL}_ACCEPTED.json']=bind(L/f'PANEL_{PANEL}_ACCEPTED.json')
   need(same(z['output_sha256'],expected),'cache outputs bound to original proof and receipt')
   keys=[s.canonical([c['profile'],t['input_raw'],t['input_D']])for c in entry['cycles']for t in c['stages']];cachecalls.append(dict(stage='local_'+action,**cache_account(z,keys,16)))
 inventory=support_inventory(ip,'INITIAL')+support_inventory(gp,'GLOBAL_RESOURCES')+(support_inventory(lp,f'LOCAL{PANEL}')if lp is not None else[])
 return dict(index=PANEL,method='accepted_local_exclusion'if entry['excluded']else('accepted_global_resource_counts'if mode=='global_count'else'accepted_local_resource_counts'),rho_interval=[str(RHO_LO),str(RHO_HI)],p_interval=[str(F(PANEL,100)),str(F(PANEL+1,100))],initial_covers=13,local_covers=covers,count_leaves=sum(x['leaves']for x in count_results),selected_counts=count_results,physical_mean_floors=floors,cache_executions=cachecalls,support_inventory=inventory)

if __name__=='__main__':
 need(__debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==3,'ordinary exact composition with independent source review and frozen selected map')
 review=read(Path(sys.argv[1]).resolve());selection_path=Path(sys.argv[2]).resolve();SELECTION=read(selection_path);configure(SELECTION['band'])
 need(review['status']=='PASS_INDEPENDENT_LOWER25_COMPLETE_COMPOSITION_SOURCE_REVIEW','explicit independent final generic source review')
 REVIEW_MAPPING=review['files_sha256'];required=[Path(__file__).resolve(),H/'compose_middle_b5_exact_v2.py',selection_path,I/'FROZEN_SOURCES.json',R/'FROZEN_SOURCES.json']
 need(all(str(p.relative_to(ROOT))in REVIEW_MAPPING for p in required),'review binds assembler, selection and exact source capsules')
 for name,h in REVIEW_MAPPING.items():bind(ROOT/name,h)
 need(SELECTION['rho_interval']==[str(RHO_LO),str(RHO_HI)],'literal lower rho branch selection')
 need((ROOT/SELECTION['global_proof']).resolve()==R/f'RESOURCE_B{B}_GLOBAL_PROOF.json'and SELECTION['global_proof_sha256']==bind(R/f'RESOURCE_B{B}_GLOBAL_PROOF.json'),'selected exact global resource proof')
 gp=read(R/f'RESOURCE_B{B}_GLOBAL_PROOF.json');ga=read(R/f'RESOURCE_B{B}_GLOBAL_ACCEPTED.json')
 need(ga['status']==f'PASS_FRESH_EXACT_SHARP25_B{B}_GLOBAL_RESOURCES'and ga['proof_sha256']==bind(R/f'RESOURCE_B{B}_GLOBAL_PROOF.json'),'complete accepted global proof')
 survivors=[row['index']for row in gp['rows']if row['result']['excluded']is False]
 need(survivors==SELECTION['global_survivors']==ga['surviving_panels']and sorted(SELECTION['panels'],key=int)==list(map(str,survivors)),'every actual survivor selected exactly once')
 need(survivors,'this fixed family expects actual surviving count targets')
 outcomes=[]
 for row in gp['rows']:
  need(type(row['index'])is int and type(row['result']['excluded'])is bool,'typed actual global outcome');PANEL=row['index']
  if row['result']['excluded']:outcomes.append(dict(index=PANEL,method='accepted_global_resource_exclusion'));continue
  CHOICE=SELECTION['panels'][str(PANEL)];need(CHOICE['mode']in('local','global_count'),'literal reviewed acquisition route')
  if CHOICE['mode']=='local':need((ROOT/CHOICE['local_capsule']).resolve()==L and str((L/'FROZEN_SOURCES.json').relative_to(ROOT))in REVIEW_MAPPING,'selected reviewed four-cycle local source')
  outcomes.append(calculate())
 need(len(outcomes)==100 and [x['index']for x in outcomes]==list(range(100)),'all100 ordered closed probability cases exhausted')
 result=dict(status='PASS_EXACT_LOWER25_COMPLETE_RHO_REGION_COMPOSITION',branch=B,n=25,K='0',rho_interval=[str(RHO_LO),str(RHO_HI)],p_interval=['0','1'],contact_allowance='5/16',owncap=PROFILE['cap'],global_signed_covers=13,local_signed_covers=sum(x.get('local_covers',0)for x in outcomes),selected_count_leaves=sum(x.get('count_leaves',0)for x in outcomes),outcomes=outcomes,conclusion=f'Within the retained attained-unrestricted-global-witness analytic framework, no positive-closed contrary witness C25>=CE has rho in[{RHO_LO},{RHO_HI}].',scope='Complete stated lower rho region only; all100 closed p cases consumed. Stronger24 and analytic reduction remain retained inputs. No FLOAT design guard or constructor interface is treated as acquisition. This is not full C25 or eventual cutoff25.',files_sha256=s.FILES)
 dest=H/f'LOWER25_B{B}_COMPLETE_EXACT_JOINED_V1.json'
 with dest.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(result['status'],B,result['selected_count_leaves'],bind(dest),flush=True)
