"""Source closure for full lower B2..B5; the arithmetic assembler stays V1.

All global count families use the existing regional V6 proof closure. The
single currently reviewed local route B2p31 is pinned to its completed local
selection; the final full assembler still rederives its actual acquisition.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
H=Path(__file__).resolve().parent;ROOT=H.parents[2]
spec=importlib.util.spec_from_file_location('regional_v6',H/'compose_lower25_regional_v6.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
read,bind,need=m.strict_read,m.c.bind,m.c.need
COMMON={'band','rho_interval','global_proof','global_proof_sha256','initial_construct_log','initial_accept_log','global_construct_log','global_accept_log'}

def validate(selection):
    need(type(selection)is dict and set(selection)==COMMON|{'schema','global_survivors','panels'},'exact complete selection fields')
    b=selection['band'];need(type(b)is int and b in(2,3,4,5),'remaining registered lower band')
    need(selection['schema']==f'LOWER25_B{b}_COMPLETE_FROZEN_SELECTION_V2','named complete selection schema')
    need(selection['rho_interval']==list(m.c.BANDS[b][:2]),'literal complete rho interval')
    survivors=selection['global_survivors'];panels=selection['panels']
    need(type(survivors)is list and survivors and all(type(i)is int and 0<=i<100 for i in survivors),'typed survivor indices')
    need(survivors==sorted(set(survivors)),'ordered unique survivor list')
    need(type(panels)is dict and set(panels)==set(map(str,survivors)),'all and only selected survivors')
    direct=dict(schema='LOWER25_FROZEN_REGIONAL_SELECTION_V1',n=25,**{k:selection[k]for k in COMMON},panels={})
    local=[]
    for i in survivors:
        choice=panels[str(i)];need(type(choice)is dict,'typed complete route')
        if choice.get('mode')=='global_count':
            direct['panels'][str(i)]=dict(p_interval=[str(F(i,100)),str(F(i+1,100))],choice=choice)
        else:
            need(choice.get('mode')=='local'and(b,i)==(2,31),'only previously reviewed B2p31 local route')
            need(set(choice)=={'mode','local_capsule','local_construct_log','local_accept_log','counts'},'exact local route fields')
            local.append(i)
    need(direct['panels'],'this selected family has direct-global survivors')
    m.validate_selection(direct)
    # Duplicate counts or logs cannot hide across the local/global boundary.
    counts=[x for choice in panels.values()for x in choice['counts']]
    need(all(type(x)is dict and set(x)=={'capsule','accept_log','forest_schema'} for x in counts),'literal count entries')
    need(len({x['capsule']for x in counts})==len(counts)and len({x['accept_log']for x in counts})==len(counts),'unique selected count capsules and logs')
    return b,direct,local

def required_closure(selection,path):
    b,direct,local=validate(selection);m.c.configure(b)
    proof=m.c.R/f'RESOURCE_B{b}_GLOBAL_PROOF.json';accepted=m.c.R/f'RESOURCE_B{b}_GLOBAL_ACCEPTED.json'
    gp,ga=read(proof),read(accepted)
    need((ROOT/selection['global_proof']).resolve()==proof and selection['global_proof_sha256']==bind(proof),'literal global parent')
    need(len(gp['rows'])==100 and all(type(z['index'])is int and z['index']==i and type(z['result']['excluded'])is bool for i,z in enumerate(gp['rows'])),'complete typed global p cover')
    actual=[z['index']for z in gp['rows']if not z['result']['excluded']]
    need(actual==selection['global_survivors']==ga['surviving_panels'],'no missing actual global survivor')
    need(ga['status']==f'PASS_FRESH_EXACT_SHARP25_B{b}_GLOBAL_RESOURCES'and ga['proof_sha256']==bind(proof),'accepted complete global resource proof')
    required=m.required_closure(direct,path)
    required.update((Path(__file__),H/'save_lower_complete_source_review_v2.py',
                     H/'LOWER_COMPLETE_V2_CAPABILITY_NOTE.txt',H/'LOWER25_REGIONAL_V6_PORT.json',
                     H/'LOWER25_REGIONAL_SCHEMA_CHECKED_V6.json',H/'LOWER25_REGIONAL_V6_PARENT_REVIEW.json'))
    reviews=[H/name for name in('THETA_VARIANCE_SOURCE_REVIEW.json','ALLOCATION_VARIANCE_SOURCE_REVIEW.json',
                               'GLOBAL_THETA_COUNT_FACTORY_SOURCE_REVIEW.json','LOWER25_RESOURCE_LOCAL_V2_REVIEW.json')]
    required.update(reviews)
    for i in local:
        source=H/'LOWER_B2_P31_SELECTION_V1.json';prior=read(source)
        need(selection['panels'][str(i)]==prior['choice'],'unchanged fully reviewed local selection')
        need(all(selection[k]==prior[k]for k in COMMON),'same initial/global parents for local route')
        joined=H/'LOWER_B2_P31_EXACT_JOINED_V1.json';receipt=read(joined)
        need(receipt['status'].startswith('PASS_EXACT_')and receipt['n']==25 and receipt['rho_interval']==selection['rho_interval'],'prior local receipt scope')
        for name,h in receipt['files_sha256'].items():bind(ROOT/name,h)
        required.update((source,joined,H.parent/'new_root/LOWER_B2_P31_SOURCE_REVIEW_V1.json'))
    return b,required,reviews
