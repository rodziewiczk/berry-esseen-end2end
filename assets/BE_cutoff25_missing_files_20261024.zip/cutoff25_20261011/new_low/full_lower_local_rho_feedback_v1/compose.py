"""Complete lower B3/B5 union with distinct acquired V13 and V14 edges.
No theorem is emitted until all selected native and regional proofs exist.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util,json,re,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1];ROOT=BASE.parents[1];A=BASE/'new_audit'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
OLD=HERE.parent/'full_lower_local_contact_v1'
old=module('full_rho_retained_union',OLD/'compose.py')
RHO_REG=ROOT/'work/cutoff25_20261013/root/local_contact_rho_regional_v1'
v8=module('full_rho_contact_region_v8',RHO_REG/'compose.py')
c,r,need,read,path=old.c,old.r,old.need,old.read,old.path
S1,SURVIVORS,LOCAL,PARENT_KEYS=old.S1,old.SURVIVORS,old.LOCAL,old.PARENT_KEYS
global_cover,old_route_only=old.global_cover,old.old_route_only
SCHEMA='LOWER25_FROZEN_COMPLETE_LOCAL_RHO_CONTACT_SELECTION_V1'
REVIEW='ROOT_REVIEWED_FULL_LOWER25_LOCAL_RHO_CONTACT_UNION_V1'
ROUTES={
 'local_contact_regional':dict(module=old.v,directory=old.REG,version=13,
  selected_mode='local_contact_count',receipt_stem='LOCAL_CONTACT',
  acquired=old.ACQUIRED,method=old.METHOD),
 'local_rho_contact_regional':dict(module=v8,directory=RHO_REG,version=14,
  selected_mode='local_rho_contact_count',receipt_stem='LOCAL_RHO_CONTACT',
  acquired='PASS_EXACT_LOWER25_SAME_WITNESS_LOCAL_RHO_CONTACT_REGIONAL_COMPOSITION',
  method='accepted_same_witness_local_rho_contact_counts_v14')}

def route(z,i):
 mode=z['panels'][str(i)]['choice']['mode'];need(mode in ROUTES,'explicit registered acquired route');return ROUTES[mode]

def validate_selection(z):
 fields={'schema','n','band','rho_interval','global_survivors','panels'}|set(PARENT_KEYS)
 need(type(z)is dict and set(z)==fields,'exact complete selection fields')
 b=z['band'];need(z['schema']==SCHEMA and type(z['n'])is int and z['n']==25 and type(b)is int and b in SURVIVORS,
                  'literal actual25 B3/B5 union')
 need(z['rho_interval']==list(c.BANDS[b][:2]),'literal rho branch')
 for key in PARENT_KEYS:need(type(z[key])is str and bool(z[key]),'literal parent provenance')
 survivors=z['global_survivors'];need(type(survivors)is list and all(type(i)is int for i in survivors)and survivors==SURVIVORS[b],
                                    'fixed ordered actual global survivors')
 panels=z['panels'];need(type(panels)is dict and set(panels)==set(map(str,survivors)),'every original survivor exactly once')
 capsules=[];logs=[];regions=[]
 for i in survivors:
  entry=panels[str(i)];need(type(entry)is dict and set(entry)=={'p_interval','choice'}and
   entry['p_interval']==[str(F(i,100)),str(F(i+1,100))],'exact original closed panel')
  choice=entry['choice'];need(type(choice)is dict,'literal route')
  mode=choice.get('mode');local=mode in ROUTES
  need(set(choice)==({'mode','counts','regional'}if local else{'mode','counts'}),'exact route fields')
  if b==3 and i==30:need(mode=='supplemental','S1 remains the only B3p30 route')
  else:need(mode=='global_count'or(local and i in LOCAL[b]),'registered original or explicit acquired route')
  counts=choice['counts'];need(type(counts)is list and len(counts)in((1,)if local or(b==3 and i==30)else(1,4)),
                             'whole acquired/S1 panel or whole/four-quarter original count')
  q=ROUTES[mode]if local else None
  for count in counts:
   need(type(count)is dict and set(count)=={'capsule','accept_log','forest_schema'}and all(type(x)is str and x for x in count.values()),
        'literal count provenance')
   d=path(count['capsule']);log=path(count['accept_log'])
   need(d.is_relative_to(BASE/'new_root')and log.is_relative_to(ROOT/'runs/cutoff25_20261011'),'registered count/log namespace')
   need((count['capsule']==S1)is(b==3 and i==30),'S1 cannot enter another route')
   need(d.name.startswith('global_local_contact_')is local,'contact capsule must use explicit acquired route')
   if local:
    need(d==q['module'].p.profile(b,i)[1]and count['forest_schema']==f"LOW25_B{b}_GLOBAL_LOCAL_CONTACT_V{q['version']}_PANEL{i}_RIGHT_HALF_CLOSED_COUNT_FOREST_V1",
         'literal versioned whole capsule and schema')
   capsules.append(str(d));logs.append(str(log))
  if local:
   ref=choice['regional'];need(type(ref)is dict and set(ref)=={'selection','selection_sha256','review','review_sha256','receipt','receipt_sha256'},
                             'complete acquired regional references')
   for key in('selection','review','receipt'):
    need(path(ref[key]).is_relative_to(q['directory']),'registered versioned regional provenance')
    need(type(ref[key+'_sha256'])is str and re.fullmatch('[0-9a-f]{64}',ref[key+'_sha256'])is not None,'literal regional digest')
   need(path(ref['receipt'])==q['directory']/f"LOWER25_B{b}_P{i}_{q['receipt_stem']}_REGIONAL_ACQUIRED_V1.json",'one actual versioned regional receipt')
   regions.append(ref['receipt'])
 need(len(set(capsules))==len(capsules)and len(set(logs))==len(logs)and len(set(regions))==len(regions),
      'no aliased or duplicated count/log/region')
 return b,survivors

def source_files():
 return old.source_files()|{HERE/n for n in('compose.py','PROOF.txt','check.py','CHECKED.json','save_source_review.py')}|{
  RHO_REG/'compose.py',RHO_REG/'PROOF.txt'}

def regional_identity(z,i,ref,selection,review,receipt):
 b=z['band'];choice=z['panels'][str(i)]['choice'];q=route(z,i);v=q['module']
 rb,ri,_=v.validate_selection(selection);need((rb,ri)==(b,i),'same exact versioned region')
 need(all(c.same(selection[k],z[k])for k in PARENT_KEYS)and c.same(selection['rho_interval'],z['rho_interval'])and
      c.same(selection['panels'][str(i)]['p_interval'],z['panels'][str(i)]['p_interval'])and
      c.same(selection['panels'][str(i)]['choice'],dict(mode=q['selected_mode'],counts=choice['counts'])),
      'same original parents and identical whole native selection')
 need(review['status']==v.REVIEW and type(review['files_sha256'])is dict and review['files_sha256'],'reviewed versioned source closure')
 need(receipt['status']==q['acquired']and type(receipt['n'])is int and receipt['n']==25 and receipt['K']=='0'and
      type(receipt['band'])is int and receipt['band']==b and type(receipt['panel'])is int and receipt['panel']==i and
      receipt['rho_interval']==z['rho_interval']and receipt['p_interval']==z['panels'][str(i)]['p_interval']and
      receipt['contact_allowance']=='5/16'and receipt['selection_sha256']==ref['selection_sha256']and
      receipt['source_review_sha256']==ref['review_sha256'],'exact distinct acquired regional identity')
 need(type(receipt['files_sha256'])is dict and receipt['files_sha256'],'complete acquired regional source closure')
 outcome=receipt['outcome'];need(type(outcome)is dict and outcome['method']==q['method']and type(outcome['index'])is int and
  outcome['index']==i and outcome['rho_interval']==z['rho_interval']and outcome['p_interval']==z['panels'][str(i)]['p_interval'],
  'explicit same-region versioned acquired method')
 extra=outcome['local_contact_extension']
 need(type(extra)is dict and extra['contact_allowance']=='5/16'and c.same(extra['premise'],v.p.PREMISE)and
      extra['capsule']==choice['counts'][0]['capsule'],'same unrestricted attained positive-closed q5/16 edge')
 if q['version']==14:
  need(type(extra['finite_feedback_rounds'])is int and extra['finite_feedback_rounds']==3 and
       type(extra['rho_upper_rounding_denominator'])is int and extra['rho_upper_rounding_denominator']==10**9,
       'explicit three-stage upward-grid local moment feedback')

def regional_record(z,i):
 q=route(z,i);ref=z['panels'][str(i)]['choice']['regional'];records={}
 for key in('selection','review','receipt'):
  p=path(ref[key]);c.bind(p,ref[key+'_sha256']);records[key]=read(p)
 selection,review,receipt=(records[k]for k in('selection','review','receipt'))
 regional_identity(z,i,ref,selection,review,receipt)
 for name,digest in review['files_sha256'].items():c.bind(path(name),digest)
 for name,digest in receipt['files_sha256'].items():
  c.bind(path(name),digest)
  need(name==ref['review']or review['files_sha256'].get(name)==digest,'every acquired dependency covered by regional gate')
 for key in('selection','review'):
  need(receipt['files_sha256'].get(ref[key])==ref[key+'_sha256'],'regional receipt binds its actual selection/review')
 for p in(q['directory']/'compose.py',q['directory']/'PROOF.txt'):
  need(receipt['files_sha256'].get(str(p.relative_to(ROOT)))==c.bind(p),'exact versioned regional implementation/proof')
 return ref,selection,review,receipt

def required_closure(z,selection_path):
 b,_=validate_selection(z);c.configure(b);required=r.required_closure(z,selection_path)|source_files()
 for i in z['global_survivors']:
  if z['panels'][str(i)]['choice']['mode']in ROUTES:
   ref,selection,review,receipt=regional_record(z,i)
   required.update(path(ref[key])for key in('selection','review','receipt'))
   required.update(path(name)for name in review['files_sha256'])
   required.update(path(name)for name in receipt['files_sha256'])
   required.update(route(z,i)['module'].required(selection,path(ref['selection'])))
 return required

def acquire_local(z,i):
 q=route(z,i);v=q['module'];ref,selection,review,receipt=regional_record(z,i)
 for name,digest in receipt['files_sha256'].items():v.c.bind(path(name),digest)
 b,index,outcome=v.acquire(path(ref['selection']))
 need((b,index)==(z['band'],i)and outcome['method']==q['method']and c.same(outcome,receipt['outcome']),
      'fresh complete versioned acquisition exactly reproduces entire regional outcome')
 for name,digest in v.c.s.FILES.items():c.bind(path(name),digest)
 return outcome

def main():
 need(__debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==3,'ordinary reviewed complete union')
 gate_path,selection_path=(Path(x).resolve()for x in sys.argv[1:]);gate=read(gate_path);z=read(selection_path)
 b,survivors=validate_selection(z);c.configure(b)
 need(gate['status']==REVIEW and type(gate['files_sha256'])is dict and gate['files_sha256'],'root-reviewed complete union graph')
 mapping=gate['files_sha256']
 for name,digest in mapping.items():c.bind(path(name),digest)
 need(all(p.is_relative_to(ROOT)and mapping.get(str(p.relative_to(ROOT)))==c.bind(p)for p in required_closure(z,selection_path)),
      'full root gate covers selected acquisition/native provenance')
 proof=c.R/f'RESOURCE_B{b}_GLOBAL_PROOF.json'
 need(path(z['global_proof'])==proof and z['global_proof_sha256']==c.bind(proof),'exact original accepted global parent')
 gp=read(proof);ga=read(c.R/f'RESOURCE_B{b}_GLOBAL_ACCEPTED.json')
 need(ga['status']==f'PASS_FRESH_EXACT_SHARP25_B{b}_GLOBAL_RESOURCES'and ga['proof_sha256']==c.bind(proof),'fresh original global parent')
 rows=global_cover(z,gp,ga);dest=HERE/f'LOWER25_B{b}_COMPLETE_LOCAL_RHO_CONTACT_EXACT_JOINED_V1.json'
 need(not dest.exists(),'exclusive full-band output')
 c.SELECTION=z;c.REVIEW_MAPPING=mapping;outcomes=[];local={key:[]for key in ROUTES};supplemental=[]
 for row in rows:
  i=row['index']
  if row['result']['excluded']:outcomes.append(dict(index=i,method='accepted_global_resource_exclusion'));continue
  choice=z['panels'][str(i)]['choice'];mode=choice['mode']
  if mode in ROUTES:
   outcome=acquire_local(z,i);expected=ROUTES[mode]['method'];local[mode].append(i)
  else:
   old_route_only(choice);c.PANEL=i;c.CHOICE=choice;outcome=c.calculate()
   expected='accepted_supplemental_resource_counts'if b==3 and i==30 else'accepted_global_resource_counts'
   if expected=='accepted_supplemental_resource_counts':supplemental.append(i)
  need(outcome['index']==i and outcome['method']==expected and outcome['rho_interval']==z['rho_interval']and
       outcome['p_interval']==z['panels'][str(i)]['p_interval']and outcome['initial_covers']==13 and outcome['local_covers']==0 and
       len(outcome['selected_counts'])==len(choice['counts']),'complete acquired panel and exact selected route')
  outcomes.append(outcome)
 need(len(outcomes)==100 and [x['index']for x in outcomes]==list(range(100))and supplemental==([30]if b==3 else[]),
      'all100 original closed cases and only registered S1 edge')
 for name,digest in list(c.s.FILES.items()):c.bind(path(name),digest)
 need(all(name==str(gate_path.relative_to(ROOT))or mapping.get(name)==digest for name,digest in c.s.FILES.items()),
      'every actually consumed source/receipt/log is covered by full root gate')
 result=dict(status='PASS_EXACT_LOWER25_COMPLETE_EXPLICIT_LOCAL_RHO_CONTACT_UNION',n=25,K='0',band=b,rho_interval=z['rho_interval'],
  p_interval=['0','1'],contact_allowance='5/16',owncap=c.PROFILE['cap'],global_signed_covers=13,
  global_exclusions=100-len(survivors),selected_count_panels=len(survivors),supplemental_panels=supplemental,
  local_contact_panels=local['local_contact_regional'],local_rho_contact_panels=local['local_rho_contact_regional'],
  selected_count_leaves=sum(x.get('count_leaves',0)for x in outcomes),outcomes=outcomes,
  selection_sha256=c.bind(selection_path),source_review_sha256=c.bind(gate_path),
  mathematical_status='Conditional exclusion of this entire rho band for the same unrestricted attained positive-closed contrary n25 witness.',
  scope='All100 closed p cases; original INITIAL/global resources; S1 only at B3p30; explicit fully reacquired V7 or V8 regions and ordinary native replay. Retained stronger24 and attainment/contact/Fourier remain inputs; not full C25 or cutoff25.',
  files_sha256=dict(c.s.FILES))
 with dest.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(result['status'],b,result['selected_count_leaves'],c.bind(dest),flush=True)
if __name__=='__main__':main()
