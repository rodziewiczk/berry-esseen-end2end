"""Join actual regional selections only after both V14 acquired receipts exist."""
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
import json,sys
import compose as m
assert __debug__ and sys.flags.dont_write_bytecode
H=Path(__file__).resolve().parent;ROOT=m.ROOT;A=m.A;J=m.RHO_REG
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
base=m.read(A/'LOWER_B3_RETAINED_REGIONAL_SELECTION_V1.json')
z={k:deepcopy(v)for k,v in base.items()if k!='panels'}
z.update(schema=m.SCHEMA,global_survivors=list(range(25,40)),panels={})
inputs={}
def take(p,i):
 p=Path(p);doc=m.read(p);inputs[str(p.relative_to(ROOT))]=sha(p)
 m.need(doc['n']==25 and type(doc['n'])is int and doc['band']==3 and type(doc['band'])is int,'original B3 only')
 m.need(doc['rho_interval']==z['rho_interval']and all(doc[k]==z[k]for k in m.PARENT_KEYS),'identical acquired global parents')
 m.need(str(i)in doc['panels'],'literal panel exists')
 return deepcopy(doc['panels'][str(i)])
for i in range(25,40):
 if i in(25,26,37,38,39):entry=take(A/'LOWER_B3_RETAINED_REGIONAL_SELECTION_V1.json',i)
 elif i==30:entry=take(A/'LOWER25_B3_P30_SUPPLEMENTAL_REGIONAL_SELECTION_V1.json',i)
 elif i in(31,32):
  p=J/f'SELECTION_B3_P{i}.json';entry=take(p,i)
  review=J/f'ROOT_REVIEW_B3_P{i}.json';receipt=J/f'LOWER25_B3_P{i}_LOCAL_RHO_CONTACT_REGIONAL_ACQUIRED_V1.json'
  claim=m.read(receipt);inputs[str(receipt.relative_to(ROOT))]=sha(receipt)
  m.need(claim['status']==m.ROUTES['local_rho_contact_regional']['acquired'],'real completed V14 acquisition')
  m.need(claim['selection_sha256']==sha(p)and claim['source_review_sha256']==sha(review),'exact selection/review receipts')
  entry['choice']['mode']='local_rho_contact_regional'
  ref={}
  for key,path in(('selection',p),('review',review),('receipt',receipt)):
   ref[key]=str(path.relative_to(ROOT));ref[key+'_sha256']=sha(path)
  entry['choice']['regional']=ref
 else:entry=take(A/f'LOWER25_B3_P{i}_REGIONAL_SELECTION_V1.json',i)
 z['panels'][str(i)]=entry
m.validate_selection(z)
for i in(31,32):m.regional_record(z,i)
dest=H/'SELECTION_B3_COMPLETE_V1.json'
with dest.open('x')as f:json.dump(z,f,indent=2);f.write('\n')
inputs[str(Path(__file__).relative_to(ROOT))]=sha(__file__)
with(H/'SELECTION_B3_COMPLETE_V1_SOURCES.json').open('x')as f:
 json.dump(dict(status='FROZEN_ACTUAL_B3_SELECTION_NOT_FULL_BAND_ACQUISITION',selection_sha256=sha(dest),inputs_sha256=inputs),f,indent=2);f.write('\n')
print('FROZEN_COMPLETE_ACTUAL_B3_SELECTION_NOT_ACQUIRED',sha(dest),flush=True)
