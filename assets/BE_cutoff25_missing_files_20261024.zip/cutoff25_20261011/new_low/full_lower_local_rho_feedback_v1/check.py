"""Pure versioned union/identity/whole-outcome fixtures; no real acquisition."""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
from hashlib import sha256
import ast,importlib.util,json,sys
assert __debug__ and sys.flags.dont_write_bytecode
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('full_rho_union_fixtures',H/'compose.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
need=m.need;controls=[]
for p in H.glob('*.py'):ast.parse(p.read_text())
need(not(H/'CHECKED.json').exists(),'exclusive fixture receipt')
def fixture(b,mode):
 z=dict(schema=m.SCHEMA,n=25,band=b,rho_interval=list(m.c.BANDS[b][:2]),global_proof='parent.json',global_proof_sha256='f'*64,
  initial_construct_log='initial_c',initial_accept_log='initial_a',global_construct_log='global_c',global_accept_log='global_a',
  global_survivors=list(m.SURVIVORS[b]),panels={})
 for i in z['global_survivors']:
  local=i in m.LOCAL[b];q=m.ROUTES[mode]
  chosen=mode if local else'supplemental'if b==3 and i==30 else'global_count'
  capsule=str(q['module'].p.profile(b,i)[1].relative_to(m.ROOT))if local else m.S1 if b==3 and i==30 else f'work/cutoff25_20261011/new_root/model_b{b}_p{i}'
  schema=f"LOW25_B{b}_GLOBAL_LOCAL_CONTACT_V{q['version']}_PANEL{i}_RIGHT_HALF_CLOSED_COUNT_FOREST_V1"if local else'model'
  choice=dict(mode=chosen,counts=[dict(capsule=capsule,accept_log=f'runs/cutoff25_20261011/low/model_b{b}_p{i}',forest_schema=schema)])
  if local:
   choice['regional']={}
   for key,filename in [('selection',f'B{b}_P{i}_SELECTION_MODEL.json'),('review',f'B{b}_P{i}_REVIEW_MODEL.json'),
                        ('receipt',f"LOWER25_B{b}_P{i}_{q['receipt_stem']}_REGIONAL_ACQUIRED_V1.json")]:
    choice['regional'][key]=str((q['directory']/filename).relative_to(m.ROOT));choice['regional'][key+'_sha256']='e'*64
  z['panels'][str(i)]=dict(p_interval=[str(F(i,100)),str(F(i+1,100))],choice=choice)
 return z
def reject(label,call):
 try:call()
 except(ValueError,KeyError,TypeError):controls.append(label)
 else:raise ValueError('malformed pure fixture admitted '+label)

for b in(3,5):
 for mode,q in m.ROUTES.items():
  z=fixture(b,mode);need(m.validate_selection(z)==(b,m.SURVIVORS[b]),'valid versioned full selection')
  gp=dict(rows=[dict(index=i,result=dict(excluded=i not in m.SURVIVORS[b]))for i in range(100)])
  ga=dict(probability_panels=100,surviving_panels=list(m.SURVIVORS[b]),excluded_panels=[i for i in range(100)if i not in m.SURVIVORS[b]])
  need(len(m.global_cover(z,gp,ga))==100,'complete typed original partition')
  i=min(m.LOCAL[b]);key=str(i);v=q['module'];other=next(k for k in m.ROUTES if k!=mode)
  def mutate(label,change):
   x=deepcopy(z);change(x);reject(f'B{b} {mode}: '+label,lambda:m.validate_selection(x))
  mutate('old full schema',lambda x:x.update(schema=m.old.SCHEMA))
  mutate('wrong actual n',lambda x:x.update(n=24))
  mutate('boolean actual n',lambda x:x.update(n=True))
  mutate('wrong band',lambda x:x.update(band=4))
  mutate('wrong rho',lambda x:x.update(rho_interval=['1','2']))
  mutate('extra field',lambda x:x.update(complete=True))
  mutate('missing survivor',lambda x:x['global_survivors'].pop())
  mutate('unordered survivors',lambda x:x['global_survivors'].reverse())
  mutate('boolean survivor',lambda x:x['global_survivors'].__setitem__(0,True))
  mutate('missing panel',lambda x:x['panels'].pop(key))
  mutate('wrong p',lambda x:x['panels'][key].update(p_interval=['0','1']))
  mutate('contact through old route',lambda x:x['panels'][key]['choice'].update(mode='global_count'))
  mutate('wrong contact version',lambda x:x['panels'][key]['choice'].update(mode=other))
  mutate('missing region',lambda x:x['panels'][key]['choice'].pop('regional'))
  mutate('extra region field',lambda x:x['panels'][key]['choice']['regional'].update(cached=True))
  mutate('bad region hash',lambda x:x['panels'][key]['choice']['regional'].update(receipt_sha256='0'))
  mutate('outside region',lambda x:x['panels'][key]['choice']['regional'].update(review='work/elsewhere.json'))
  mutate('four contact quarters',lambda x:x['panels'][key]['choice']['counts'].__imul__(4))
  mutate('wrong native schema',lambda x:x['panels'][key]['choice']['counts'][0].update(forest_schema='old'))
  mutate('wrong capsule version',lambda x:x['panels'][key]['choice']['counts'][0].update(capsule=str(m.ROUTES[other]['module'].p.profile(b,i)[1].relative_to(m.ROOT))))
  mutate('wrong native panel',lambda x:x['panels'][key]['choice']['counts'][0].update(capsule=str(v.p.profile(b,i+1)[1].relative_to(m.ROOT))))
  mutate('outside log',lambda x:x['panels'][key]['choice']['counts'][0].update(accept_log='/private/tmp/log'))
  mutate('duplicate log',lambda x:x['panels'][key]['choice']['counts'][0].update(accept_log=x['panels'][str(i+1)]['choice']['counts'][0]['accept_log']))
  if b==3:mutate('old route at S1',lambda x:x['panels']['30']['choice'].update(mode='global_count'))
  else:mutate('S1 in B5',lambda x:x['panels']['19']['choice'].update(mode='supplemental'))
  for label,change in (
   ('missing row',lambda x,y:x['rows'].pop()),('unordered cases',lambda x,y:x['rows'].reverse()),
   ('boolean index',lambda x,y:x['rows'][0].update(index=False)),('integer excluded',lambda x,y:x['rows'][0]['result'].update(excluded=1)),
   ('omitted survivor',lambda x,y:x['rows'][i]['result'].update(excluded=True)),('new survivor',lambda x,y:x['rows'][0]['result'].update(excluded=False)),
   ('receipt gap',lambda x,y:y['excluded_panels'].pop()),('boolean total',lambda x,y:y.update(probability_panels=True))):
   x,y=deepcopy(gp),deepcopy(ga);change(x,y);reject(f'B{b} {mode} cover '+label,lambda:m.global_cover(z,x,y))
  choice=z['panels'][key]['choice'];ref=choice['regional']
  sel={k:deepcopy(z[k])for k in('n','band','rho_interval',*m.PARENT_KEYS)}
  sel.update(schema=v.SCHEMA,panels={key:dict(p_interval=z['panels'][key]['p_interval'],choice=dict(mode=q['selected_mode'],counts=deepcopy(choice['counts'])))})
  review=dict(status=v.REVIEW,files_sha256={'model':'f'*64})
  extra=dict(capsule=choice['counts'][0]['capsule'],contact_allowance='5/16',premise=deepcopy(v.p.PREMISE))
  if q['version']==14:extra.update(finite_feedback_rounds=3,rho_upper_rounding_denominator=10**9)
  outcome=dict(index=i,method=q['method'],rho_interval=z['rho_interval'],p_interval=z['panels'][key]['p_interval'],local_contact_extension=extra)
  receipt=dict(status=q['acquired'],n=25,K='0',band=b,panel=i,rho_interval=z['rho_interval'],p_interval=z['panels'][key]['p_interval'],contact_allowance='5/16',
   selection_sha256=ref['selection_sha256'],source_review_sha256=ref['review_sha256'],files_sha256={'model':'f'*64},outcome=outcome)
  m.regional_identity(z,i,ref,sel,review,receipt)
  def regional(label,change):
   x,y,t=deepcopy(sel),deepcopy(review),deepcopy(receipt);change(x,y,t)
   reject(f'B{b} {mode} regional '+label,lambda:m.regional_identity(z,i,ref,x,y,t))
  regional('different global parent',lambda x,y,t:x.update(global_proof='other'))
  regional('different initial log',lambda x,y,t:x.update(initial_accept_log='other'))
  regional('different native selection',lambda x,y,t:x['panels'][key]['choice']['counts'][0].update(accept_log='other'))
  regional('wrong review version',lambda x,y,t:y.update(status=m.ROUTES[other]['module'].REVIEW))
  regional('missing review graph',lambda x,y,t:y.update(files_sha256={}))
  regional('wrong acquired version',lambda x,y,t:t.update(status=m.ROUTES[other]['acquired']))
  regional('boolean receipt n',lambda x,y,t:t.update(n=True))
  regional('wrong panel',lambda x,y,t:t.update(panel=i+1))
  regional('wrong q',lambda x,y,t:t.update(contact_allowance='1/4'))
  regional('wrong selection hash',lambda x,y,t:t.update(selection_sha256='0'*64))
  regional('wrong gate hash',lambda x,y,t:t.update(source_review_sha256='0'*64))
  regional('missing receipt graph',lambda x,y,t:t.update(files_sha256={}))
  regional('wrong acquired method',lambda x,y,t:t['outcome'].update(method=m.ROUTES[other]['method']))
  regional('boolean outcome panel',lambda x,y,t:t['outcome'].update(index=True))
  regional('wrong extension q',lambda x,y,t:t['outcome']['local_contact_extension'].update(contact_allowance='1/4'))
  regional('false attained orientation',lambda x,y,t:t['outcome']['local_contact_extension']['premise'].update(positive_closed_threshold=False))
  regional('missing attained premise',lambda x,y,t:t['outcome']['local_contact_extension']['premise'].pop('same_unrestricted_attained_witness'))
  regional('wrong extension capsule',lambda x,y,t:t['outcome']['local_contact_extension'].update(capsule='other'))
  if q['version']==14:
   for field,value in (('finite_feedback_rounds',True),('finite_feedback_rounds',4),('rho_upper_rounding_denominator',True),('rho_upper_rounding_denominator',10**8)):
    regional('wrong '+field+' '+str(value),lambda x,y,t,field=field,value=value:t['outcome']['local_contact_extension'].update({field:value}))
  # Isolated mocked reacquisition: exact full-result equality, not method-only.
  saved_record=m.regional_record;saved_acquire=v.acquire;saved_vbind=v.c.bind;saved_bind=m.c.bind;saved_files=v.c.s.FILES
  try:
   m.regional_record=lambda z,i:(ref,sel,review,receipt)
   v.c.bind=lambda *a:None;m.c.bind=lambda *a:None;v.c.s.FILES={}
   v.acquire=lambda p:(b,i,deepcopy(outcome))
   need(m.acquire_local(z,i)==outcome,'matching entire acquired result')
   for label,change in (
    ('changed same-method payload',lambda o:o.update(count_leaves=999)),
    ('lost same-law premise',lambda o:o['local_contact_extension'].pop('premise'))):
    bad=deepcopy(outcome);change(bad);v.acquire=lambda p,bad=bad:(b,i,bad)
    reject(f'B{b} {mode} reacquire '+label,lambda:m.acquire_local(z,i))
  finally:
   m.regional_record=saved_record;v.acquire=saved_acquire;v.c.bind=saved_vbind;m.c.bind=saved_bind;v.c.s.FILES=saved_files
 # Mixed V13/V14 selections must also preserve the complete partition.
 z=fixture(b,'local_contact_regional');new=fixture(b,'local_rho_contact_regional')
 for i in m.LOCAL[b]:
  if i%2:z['panels'][str(i)]=new['panels'][str(i)]
 need(m.validate_selection(z)==(b,m.SURVIVORS[b]),'mixed versioned route cover')
 d=m.BASE/f'new_root/resource25_b{b}_v1';gp=json.loads((d/f'RESOURCE_B{b}_GLOBAL_PROOF.json').read_text());ga=json.loads((d/f'RESOURCE_B{b}_GLOBAL_ACCEPTED.json').read_text())
 need(len(m.global_cover(z,gp,ga))==100,'actual original global partition')
need(len(controls)==len(set(controls)),'distinct malformed controls')
files=(m.source_files()-{H/'CHECKED.json'})|{m.A/'compose_lower25_regional_v6.py',m.A/'compose_lower25_complete_v1.py',m.A/'compose_middle_b5_exact_v2.py'}
for b in(3,5):
 for suffix in('PROOF','ACCEPTED'):files.add(m.BASE/f'new_root/resource25_b{b}_v1/RESOURCE_B{b}_GLOBAL_{suffix}.json')
out=dict(status='PASS_SOURCE_ONLY_FULL_LOWER25_EXPLICIT_V13_V14_UNION_FIXTURES',negative_controls=controls,
 actual_global_cases={'3':100,'5':100},actual_survivors={str(b):m.SURVIVORS[b]for b in(3,5)},
 source_sha256={str(p):sha256(p.read_bytes()).hexdigest()for p in sorted(files)},
 scope='Pure malformed selection/cover/versioned identity and isolated mocked whole-outcome comparison; read-only original partitions. No real calculate/acquire/native evaluator/gate/union.')
with(H/'CHECKED.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(out['status'],len(controls),sha256((H/'CHECKED.json').read_bytes()).hexdigest())
