"""Bind the fully reviewed union only after all real regional/native receipts."""
from pathlib import Path
import importlib.util,json,sys
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('full_local_rho_union',H/'compose.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert __debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==4
selection_path,source_gate_path,dest=(Path(x).resolve()for x in sys.argv[1:])
m.need(selection_path.is_relative_to(H)and source_gate_path.is_relative_to(H)and dest.is_relative_to(H)and not dest.exists(),
       'new reviewed local complete selection/gate')
gate=m.read(source_gate_path)
m.need(gate['status']=='ROOT_APPROVED_FULL_LOWER25_LOCAL_RHO_CONTACT_UNION_SOURCE_V1','separate completed root source review')
for name,digest in gate['files_sha256'].items():m.c.bind(m.path(name),digest)
for p in m.source_files():m.need(gate['files_sha256'].get(str(p.relative_to(m.ROOT)))==m.c.bind(p),'root reviewed every complete union source')
z=m.read(selection_path);b,_=m.validate_selection(z);m.c.configure(b)
gp=m.read(m.c.R/f'RESOURCE_B{b}_GLOBAL_PROOF.json');ga=m.read(m.c.R/f'RESOURCE_B{b}_GLOBAL_ACCEPTED.json');m.global_cover(z,gp,ga)
required=m.required_closure(z,selection_path)|{source_gate_path,Path(__file__).resolve()}
reviews=[m.A/n for n in('THETA_VARIANCE_SOURCE_REVIEW.json','ALLOCATION_VARIANCE_SOURCE_REVIEW.json',
                      'GLOBAL_THETA_COUNT_FACTORY_SOURCE_REVIEW.json','LOWER25_RESOURCE_LOCAL_V2_REVIEW.json')]
required.update(reviews)
for p in sorted(required):m.c.bind(p)
for p in sorted(required):
 if p.suffix=='.json'and('SOURCE_REVIEW'in p.name or p in reviews or p.name=='COMMON_CUBIC_RUNTIME_V2_REVIEW.json'):
  value=m.read(p)
  for field in('files_sha256','source_sha256'):
   for name,digest in value.get(field,{}).items():m.c.bind(Path(name)if Path(name).is_absolute()else m.ROOT/name,digest)
for key,entry in z['panels'].items():
 i=int(key);choice=entry['choice']
 if choice['mode']not in m.ROUTES:m.old_route_only(choice)
 for count in choice['counts']:
  d=m.path(count['capsule']);receipt=m.read(d/f'COUNT{i}_ACCEPTED.json');forest=m.read(d/f'COUNT{i}_FOREST.json');contract=m.read(d/'contract.json')
  m.need(receipt['status']==f'PASS_FRESH_CONDITIONAL_EXACT_COUNT{i}'and receipt['forest_sha256']==m.c.bind(d/f'COUNT{i}_FOREST.json')and
         receipt['checker_sha256']==m.c.bind(d/'count_protocol.py')and receipt['contract_sha256']==m.c.bind(d/'contract.json')and
         forest['schema']==count['forest_schema'],'actual native receipt bound to selected count')
  km=m.read(d/'KERNEL_COPY_MANIFEST.json')['files'];m.need(m.c.same(receipt['kernel_sha256'],km),'full actual native runtime')
  for name,digest in km.items():m.c.bind(d/name,digest)
  for name,digest in contract['source_inputs_sha256'].items():m.c.bind(m.ROOT/name,digest)
  if b==3 and i==30:m.r.edge.count_sources(m.c,contract)
  log=m.path(count['accept_log']);meta=m.read(log/'metadata.json');m.need(type(meta['returncode'])is int and meta['returncode']==0,'completed native execution')
  m.c.bind(log/'stdout.txt',meta['stdout_sha256']);m.c.bind(log/'stderr.txt',meta['stderr_sha256'])
for name,digest in list(m.c.s.FILES.items()):m.c.bind(m.ROOT/name,digest)
out=dict(status=m.REVIEW,reviewer='/root',root_source_review_sha256=m.c.bind(source_gate_path),band=b,panels=z['global_survivors'],
 mathematical_status='Source gate for complete finite union with unchanged old acquisitions and explicit reacquired V7/V8 local-contact regions.',
 execution_status='Source/provenance binding only. No full union or regional acquire called by this binder.',files_sha256=dict(sorted(m.c.s.FILES.items())))
with dest.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(out['status'],len(out['files_sha256']),m.c.bind(dest),flush=True)
