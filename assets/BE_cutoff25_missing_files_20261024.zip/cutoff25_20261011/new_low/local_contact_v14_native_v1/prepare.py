"""Source-gated V14 native port: original global guards plus attained contact.

Usage: prepare.py BAND INDEX. No forest, checkpoint or arithmetic replay.
"""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import ast,difflib,json,shutil,sys

H=Path(__file__).resolve().parent;W=H.parents[1];ROOT=W.parents[1];R=W/'new_root'
CENTRAL=ROOT/'work/cutoff25_20261013/b5/local_contact_v14_combined'
GATE=H/'ROOT_REVIEW.json'
STATUS='ROOT_REVIEWED_LOCAL_CONTACT_V14_NATIVE_PRODUCER_V1'
CORE='a618867ae34841b2e3e1745e35142694142e08ca2d790b762870f50651e16d71'
PREMISE=dict(schema='ATTAINED_POSITIVE_CLOSED_CONTACT_V1',sample_size=25,
 same_unrestricted_attained_witness=True,positive_closed_threshold=True,score_at_least_CE=True)
RHO={3:['13/10','7/5'],5:['3/2','33/20']}
ADDITIONS={'local_contact_v13.py','local_contact_support.py','local_contact_gaussian.py',
 'local_contact_scale.py','local_contact_binomial.py','local_contact_heat.py',
 'LOCAL_CONTACT_PROOF.txt','LOCAL_CONTACT_SOURCE_PORT.json','LOCAL_CONTACT_SOURCE_PORT.diff',
 'LOCAL_CONTACT_ADDITIONS.json','local_contact_outer_v14.py',
 'LOCAL_CONTACT_OUTER_V14_PROOF.txt','LOCAL_CONTACT_OUTER_V14_SOURCE_PORT.json',
 'LOCAL_CONTACT_OUTER_V14_ADDITIONS.json','SHARP_CUBIC_PROOF.txt',
 'LOCAL_RHO_UPPER_PROOF.txt','LOCAL_RHO_MATHEMATICAL_REVIEW.json',
 'local_contact_v14.py','local_rho_upper_v14.py','LOCAL_CONTACT_V14_PROOF.txt',
 'LOCAL_CONTACT_V14_SOURCE_PORT.json'}


def need(ok,message):
 if not ok:raise ValueError(message)
def sha(path):return sha256(Path(path).read_bytes()).hexdigest()
def unique(items):
 out={}
 for name,value in items:need(name not in out,'duplicate JSON key');out[name]=value
 return out
def read(path):return json.loads(Path(path).read_text(),object_pairs_hook=unique)
def same(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 return a==b
def profile(b,i):
 need(type(b)is int and b in(3,5)and type(i)is int and 0<i<99,'literal registered band/index')
 return R/f'global_alpha_stoploss2_b{b}_p{i}_v12',R/f'global_local_contact_b{b}_p{i}_v14'

def checker(before,b,i):
 old='from rho_signed_moment_tightener import cell35'
 anchor=" cfg=contract['rows'][0]\n"
 label=f'LOW25_B{b}_GLOBAL_ALPHA_STOPLOSS2_V12_PANEL{i}_RIGHT_HALF_CLOSED_COUNT_FOREST_V1'
 newlabel=f'LOW25_B{b}_GLOBAL_LOCAL_CONTACT_V14_PANEL{i}_RIGHT_HALF_CLOSED_COUNT_FOREST_V1'
 need(before.count(old)==before.count(anchor)==before.count(label)==1,'three unique literal native source ports')
 after=before.replace(old,'from local_contact_v14 import cell35,validate_premise').replace(label,newlabel)
 after=after.replace(anchor,anchor+' validate_premise(cfg)\n')
 ast.parse(after)
 return after

def required(b,i):
 """Read-only complete producer/native/helper source inventory for root review."""
 S,D=profile(b,i);mapping={}
 def bind(path,digest=None):
  path=Path(path).resolve();need(path.is_relative_to(ROOT),'workspace source');value=sha(path)
  need(digest is None or value==digest,'current fixed source '+str(path));mapping[str(path)]=value;return value
 for name in('prepare.py','PROOF.txt','check_source.py','CHECKED.json'):bind(H/name)
 additions=read(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json');bind(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json')
 need(type(additions)is dict and set(additions)=={'files','source_directory'}and
      additions['source_directory']==str(CENTRAL),'literal complete central additions manifest')
 files=additions['files']
 need(type(files)is dict and set(files)==ADDITIONS,'exact complete local-contact arithmetic/proof stack')
 need('LOCAL_CONTACT_V14_ADDITIONS.json'not in files and 'KERNEL_COPY_MANIFEST.json'not in files,
      'no self-hash or manifest cycle')
 for name,digest in files.items():
  need(type(name)is str and Path(name).name==name and type(digest)is str,'literal central filename/hash')
  bind(CENTRAL/name,digest)
 manifest=read(S/'KERNEL_COPY_MANIFEST.json');bind(S/'KERNEL_COPY_MANIFEST.json')
 need(manifest['files'].get('exact35_core.py')==CORE and not(set(files)|{'LOCAL_CONTACT_V14_ADDITIONS.json'})&set(manifest['files']),
      'unchanged V12 and disjoint isolated local-contact additions')
 for name,digest in manifest['files'].items():bind(S/name,digest)
 bind(S/'count_protocol.py');bind(S/'contract.json')
 old=read(S/'contract.json');need(type(old['rows'])is list and len(old['rows'])==1,'one original conditional row')
 cfg=old['rows'][0]
 need(type(cfg['n'])is int and cfg['n']==25 and type(cfg['index'])is int and cfg['index']==i and cfg['K']=='0'and
      cfg['p']==[str(F(i,100)),str(F(i+1,100))]and[cfg['rho_lower'],cfg['rho_upper']]==RHO[b],
      'exact original whole-panel actual25 profile')
 need('local_contact_premise'not in cfg and 'local_contact_allowance'not in cfg,'no preexisting contact extension')
 for name,digest in old['source_inputs_sha256'].items():bind(ROOT/name,digest)
 checker((S/'count_protocol.py').read_text(),b,i)
 return mapping

def main():
 need(__debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==3,'ordinary fixed native preparation')
 b,i=map(int,sys.argv[1:]);S,D=profile(b,i);need(not D.exists(),'new native capsule only')
 sources=required(b,i);review=read(GATE)
 need(review['status']==STATUS and type(review.get('source_sha256'))is dict and
      all(review['source_sha256'].get(name)==digest for name,digest in sources.items()),
      'root review pins complete producer, old native and central local-contact stack')
 for name,digest in review['source_sha256'].items():
  p=Path(name).resolve();need(str(p)==name and p.is_relative_to(ROOT)and sha(p)==digest,'current complete reviewed source')
 sources.update(review['source_sha256']);sources[str(GATE)]=sha(GATE)
 additions=read(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json');old=read(S/'contract.json')
 manifest=read(S/'KERNEL_COPY_MANIFEST.json');before=(S/'count_protocol.py').read_text();after=checker(before,b,i)
 contract=deepcopy(old);cfg=contract['rows'][0]
 cfg['local_contact_allowance']='5/16';cfg['local_contact_premise']=deepcopy(PREMISE)
 need(same({k:v for k,v in cfg.items()if k not in('local_contact_allowance','local_contact_premise')},old['rows'][0]),
      'all original physical guards unchanged')
 contract['status']='EXACT_GLOBAL_GUARDS_AND_LOCAL_CONTACT_RHO_FEEDBACK_CONDITIONAL_UNTIL_V8_COMPOSITION'
 contract['source_inputs_sha256'].update({str(Path(name).relative_to(ROOT)):digest for name,digest in sources.items()})
 contract['scope']='Same original attained unrestricted positive-closed contrary n25 witness with q5/16. Original global physical guards plus explicit local contact premise; independently reviewed three-stage local rho/support feedback on original count boxes. All ordinary native replay and acquired V8 regional composition remain separate obligations.'
 D.mkdir(exist_ok=False)
 for name,digest in manifest['files'].items():need(sha(S/name)==digest,'stable original native bytes');shutil.copyfile(S/name,D/name)
 for name,digest in additions['files'].items():need(sha(CENTRAL/name)==digest,'stable central native addition');shutil.copyfile(CENTRAL/name,D/name)
 shutil.copyfile(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json',D/'LOCAL_CONTACT_V14_ADDITIONS.json')
 kernel=deepcopy(manifest);kernel['files'].update(additions['files']);kernel['files']['LOCAL_CONTACT_V14_ADDITIONS.json']=sha(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json')
 (D/'count_protocol.py').write_text(after)
 port=dict(status='SOURCE_ONLY_V14_NATIVE_PORT_NOT_ACCEPTED',producer_sha256=sha(Path(__file__)),source_review_sha256=sha(GATE),
  source_native=str(S),source_contract_sha256=sha(S/'contract.json'),source_checker_sha256=sha(S/'count_protocol.py'),
  source_kernel_manifest_sha256=sha(S/'KERNEL_COPY_MANIFEST.json'),central_additions_manifest_sha256=sha(CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json'),
  source_sha256=sources,checker_diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True))),
  scope='Import, explicit attained-contact load guard and distinct schema only. All original V12 kernel bytes, strict CE target, original26-root geometry,10000-node/depth128 cap, exact replay and24 native controls unchanged.')
 for name,value in(('contract.json',contract),('KERNEL_COPY_MANIFEST.json',kernel),('SOURCE_PORT.json',port)):
  with(D/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
 frozen=dict(files={p.name:sha(p)for p in D.iterdir()if p.is_file()})
 with(D/'FROZEN_DESIGN.json').open('x')as f:json.dump(frozen,f,indent=2);f.write('\n')
 need(all(sha(name)==digest for name,digest in sources.items()),'source graph unchanged through preparation')
 print('LOCAL_CONTACT_V14_NATIVE_PREPARED_NOT_ACCEPTED',b,i,len(kernel['files']),sha(D/'contract.json'),flush=True)
if __name__=='__main__':main()
