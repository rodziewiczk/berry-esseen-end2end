"""Source-only native-port and attained-premise fixtures; no count evaluation."""
from pathlib import Path
from copy import deepcopy
import ast,importlib.util,json,sys
import prepare as p
H=Path(__file__).resolve().parent
assert __debug__ and sys.flags.dont_write_bytecode
p.need(not(H/'CHECKED.json').exists(),'exclusive producer source test output')
for path in H.glob('*.py'):ast.parse(path.read_text())
sys.path.insert(0,str(p.CENTRAL))
import local_contact_support as s
p.need(s.same(s.PREMISE,p.PREMISE),'identical complete conditional premise schema')
cfg={'n':25,'K':'0','local_contact_allowance':'5/16','local_contact_premise':deepcopy(p.PREMISE)}
s.validate_premise(cfg)
controls=[]
def reject(label,call):
 try:call()
 except(ValueError,KeyError,TypeError):controls.append(label)
 else:raise ValueError('bad source fixture accepted: '+label)
def mutate(label,change):
 value=deepcopy(cfg);change(value);reject(label,lambda:s.validate_premise(value))
mutate('wrong actual n',lambda x:x.update(n=24))
mutate('boolean actual n',lambda x:x.update(n=True))
mutate('positive K',lambda x:x.update(K='1/100'))
mutate('numeric K',lambda x:x.update(K=0))
mutate('missing allowance',lambda x:x.pop('local_contact_allowance'))
mutate('different contact allowance',lambda x:x.update(local_contact_allowance='1/4'))
mutate('nontext allowance',lambda x:x.update(local_contact_allowance=p.F(5,16)))
mutate('missing premise',lambda x:x.pop('local_contact_premise'))
mutate('wrong premise schema',lambda x:x['local_contact_premise'].update(schema='old'))
mutate('wrong premise n',lambda x:x['local_contact_premise'].update(sample_size=24))
mutate('boolean premise n',lambda x:x['local_contact_premise'].update(sample_size=True))
for key in('same_unrestricted_attained_witness','positive_closed_threshold','score_at_least_CE'):
 mutate('false '+key,lambda x,key=key:x['local_contact_premise'].update({key:False}))
 mutate('integer '+key,lambda x,key=key:x['local_contact_premise'].update({key:1}))
mutate('extra premise field',lambda x:x['local_contact_premise'].update(extra=True))
mutate('missing premise field',lambda x:x['local_contact_premise'].pop('score_at_least_CE'))
for b,i in((True,31),(4,31),(3,0),(5,99),(3,True)):
 reject('unsupported profile '+repr((b,i)),lambda b=b,i=i:p.profile(b,i))
ports=[];source={}
for b,i in((3,31),(3,32),*((5,j)for j in range(24,33))):
 S,D=p.profile(b,i);path=S/'count_protocol.py';before=path.read_text();after=p.checker(before,b,i)
 old={x.name:x for x in ast.parse(before).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
 new={x.name:x for x in ast.parse(after).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
 p.need(old.keys()==new.keys(),'same complete native function inventory')
 p.need(all(ast.dump(old[name])==ast.dump(new[name])for name in old if name not in('load','header')),
        'evaluate/replay/accept/24controls and remaining functions unchanged')
 p.need(len(new['load'].body)==len(old['load'].body)+1,'exactly one added premise invocation')
 ports.append(dict(band=b,index=i,source=str(path),sha256=p.sha(path),destination_name=D.name,
                   unchanged_functions=sorted(name for name in old if name not in('load','header'))))
 source[str(path)]=p.sha(path)
 reject('missing import '+str((b,i)),lambda:p.checker(before.replace('from rho_signed_moment_tightener import cell35',''),b,i))
 reject('duplicated import '+str((b,i)),lambda:p.checker(before+'\nfrom rho_signed_moment_tightener import cell35\n',b,i))
 reject('missing row anchor '+str((b,i)),lambda:p.checker(before.replace(" cfg=contract['rows'][0]\n",''),b,i))
for path in H.iterdir():
 if path.is_file():source[str(path)]=p.sha(path)
additions=p.read(p.CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json')
p.need(set(additions)=={'files','source_directory'}and additions['source_directory']==str(p.CENTRAL)and
       set(additions['files'])==p.ADDITIONS,'exact isolated central additions inventory')
for name,digest in additions['files'].items():
 path=p.CENTRAL/name;p.need(p.sha(path)==digest,'current central addition '+name);source[str(path)]=digest
source[str(p.CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json')]=p.sha(p.CENTRAL/'LOCAL_CONTACT_V14_ADDITIONS.json')
out=dict(status='PASS_SOURCE_ONLY_LOCAL_CONTACT_V14_NATIVE_PORT_AND_PREMISE_FIXTURES',source_sha256=source,
 negative_controls=controls,checked_ports=ports,
 scope='Pure premise and literal checker-port tests only. No native capsule preparation, native cell evaluation, discovery, acceptance or acquired regional conclusion.')
with(H/'CHECKED.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(out['status'],len(controls),p.sha(H/'CHECKED.json'),flush=True)
