"""Exact optional acquired signed moments and alpha contraction; no acquisition."""
from probability_extrema import variance_extrema
from mean_variance import contract as mean_contract
from theta_variance import contract as theta_contract
from allocation_variance import contract as allocation_contract
from moment_corners import beta_corners,alpha_corners
from fractions import Fraction as F
import exact35_core as c
from optimized_arithmetic import cell35 as base_cell35
from signed_beta_variance_floor import lower_lambda
from rho_variance_floor import lower_lambda as rho_lower_lambda

def moment_box(pl,pu,lo,hi,al,ah,n):
    # Literal same-orientation p in (0,1); pq extrema include the half seam.
    c.need(0<pl<=pu<1 and 0<=lo<=hi and 0<=al<=ah<=1,'signed moment box domain')
    vl,vh=variance_extrema(pl,pu)
    v=c.I(vl,vh);p=c.I(pl,pu);s=c.I(lo/n,hi/n);alpha=c.I(al,ah)
    beta=(v*(1-2*p)+s*(2*alpha-1))/(v+s)
    corners=beta_corners(pl,pu,lo/n,hi/n,al,ah)if pu<F(1,2)else None
    if corners is not None:beta=c.I(max(beta.l,corners[0]),min(beta.h,corners[1]))
    # v/sqrt(v+s) increases in v and decreases in s for v>0,s>=0.
    ml=vl/c.root(vl+s.h,10**12)[1]
    mh=vh/c.root(vh+s.l,10**12)[0]
    return beta,c.I(ml,mh)

def cell35(cfg,pl,pu,lo,hi,al,ah,k,ul,uh,a0l,a0h):
    c.validate_resources(cfg)
    n=cfg['n'];Lambda=F(cfg['Lambda']);d0=F(cfg['d0'])
    c.need(type(k)is int and 0<=k<=n,'actual count')
    c.need(all(type(x)is F for x in(pl,pu,lo,hi,al,ah,ul,uh,a0l,a0h)),'rational cell')
    c.need(F(cfg['p'][0])<=pl<=pu<=F(cfg['p'][1]) and 0<=lo<=hi<=Lambda and 0<=al<=ah<=1 and -F(1,2)<=ul<=uh<=F(1,2) and 0<=a0l<=a0h<=d0,'closed selected cell')
    for name in ('acquired_beta','acquired_mean'):
        c.need(type(cfg[name])is list and len(cfg[name])==2 and all(type(x)is str for x in cfg[name]),'explicit rational signed moment premise')
    bl,bh=map(F,cfg['acquired_beta']);ml,mh=map(F,cfg['acquired_mean'])
    c.need(-1<=bl<=bh<=1 and 0<=ml<=mh<=F(1,2),'ordered physical signed moment premises')
    c.need(all(type(cfg[name])is str for name in ('rho_lower','outer0','outer1')),'explicit rational rho and count-coordinate outer caps')
    c.need(type(cfg['acquired_theta_upper'])is str,'explicit acquired physical theta premise')
    theta_cut=theta_contract(n,pl,pu,lo,hi,F(cfg['acquired_theta_upper']))
    if theta_cut['empty']:return dict(status='EMPTY_ACQUIRED_THETA_VARIANCE',**theta_cut)
    lo,hi=theta_cut['lo'],theta_cut['hi']
    allocation_cut=allocation_contract(n,pl,pu,lo,hi,al,ah,d0,Lambda,F(cfg['outer0']),F(cfg['outer1']))
    if allocation_cut['empty']:return dict(status='EMPTY_SUPPORT_GAP_VARIANCE',**allocation_cut)
    lo,hi=allocation_cut['lo'],allocation_cut['hi']
    mean_cut=mean_contract(n,pl,pu,lo,hi,ml,mh)
    if mean_cut['empty']:return dict(status='EMPTY_ACQUIRED_MEAN_VARIANCE',**mean_cut)
    lo,hi=mean_cut['lo'],mean_cut['hi']
    rho_floor=rho_lower_lambda(n,pl,pu,lo,hi,al,ah,F(cfg['rho_lower']),F(cfg['outer0']),F(cfg['outer1']))
    if rho_floor['empty']:return dict(status='EMPTY_ACQUIRED_RHO_VARIANCE',**rho_floor)
    lo=rho_floor['lo']
    floored=lower_lambda(n,pl,pu,lo,hi,al,ah,bl,bh)
    if floored['empty']:return dict(status='EMPTY_ACQUIRED_BETA_VARIANCE',**floored)
    lo=floored['lo']
    beta,mean=moment_box(pl,pu,lo,hi,al,ah,n)
    if beta.h<bl or beta.l>bh:
        return dict(status='EMPTY_ACQUIRED_BETA',beta_lower=str(beta.l),beta_upper=str(beta.h))
    if mean.h<ml or mean.l>mh:
        return dict(status='EMPTY_ACQUIRED_MEAN',mean_lower=str(mean.l),mean_upper=str(mean.h))
    if lo>0:
        v=c.I(*variance_extrema(pl,pu));p=c.I(pl,pu);s=c.I(lo/n,hi/n)
        acquired=c.I(bl,bh)
        possible=(acquired*(v+s)-v*(1-2*p)+s)/(2*s)
        corners=alpha_corners(pl,pu,lo/n,hi/n,bl,bh)if pu<F(1,2)else None
        if corners is not None:possible=c.I(max(possible.l,corners[0]),min(possible.h,corners[1]))
        al=max(al,possible.l);ah=min(ah,possible.h)
        if al>ah:return dict(status='EMPTY_ACQUIRED_ALPHA',alpha_lower=str(al),alpha_upper=str(ah))
    allocation_cut=allocation_contract(n,pl,pu,lo,hi,al,ah,d0,Lambda,F(cfg['outer0']),F(cfg['outer1']))
    if allocation_cut['empty']:return dict(status='EMPTY_SUPPORT_GAP_VARIANCE',**allocation_cut)
    lo,hi=allocation_cut['lo'],allocation_cut['hi']
    return base_cell35(cfg,pl=pl,pu=pu,lo=lo,hi=hi,al=al,ah=ah,k=k,ul=ul,uh=uh,a0l=a0l,a0h=a0h)
