"""Exact incoming-only finite-alpha covers; native use requires source review."""
from fractions import Fraction as F
from integer_stoploss import joint
from quadratic_stoploss import optimal_tau, endpoint


def envelopes(n,j,k,pl,pu,hi,al,ah,ul,uh,s0_upper,s1_upper,O0,a1,parts=4):
    assert type(n)is int and type(j)is int and type(k)is int
    assert 0<=k<j<=n and j<=k+2 and n>0
    assert type(parts)is int and parts in(2,4)
    values=(pl,pu,hi,al,ah,ul,uh,s0_upper,s1_upper,O0,a1)
    assert all(type(x)is F for x in values)
    assert 0<pl<=pu<1 and hi>=0 and 0<=al<=ah<=1 and ul<=uh
    assert s0_upper>=0 and s1_upper>=0 and O0>=0 and a1>=0
    right_distance=F(j-k)-uh;left_distance=F(j-k)-ul
    assert left_distance>=right_distance>0
    subparts=[]
    for i in range(parts):
        a=al+(ah-al)*F(i,parts);b=al+(ah-al)*F(i+1,parts)
        v0=min(s0_upper,hi*(1-a)/(n*(1-pu)))
        v1=min(s1_upper,hi*b/(n*pl))
        assert 0<=v0<=s0_upper and 0<=v1<=s1_upper
        law=joint(n,j,O0,v0,a1,v1)
        choices=[]
        for distance in (right_distance,left_distance):
            tau=optimal_tau(law,distance)
            right=endpoint(law,right_distance,tau)
            left=endpoint(law,left_distance,tau)
            assert 0<=left<=right
            choices.append((right,left))
        subparts.append(choices)
    result=[]
    for strategy in (0,1):
        right=max(x[strategy][0]for x in subparts)
        left=max(x[strategy][1]for x in subparts)
        slope=(right-left)/(uh-ul)if uh>ul else F(0)
        assert right>=left>=0 and slope>=0
        result.append((right,left,slope))
    return tuple(result)
