"""Centered exponential-excess tail and a frozen affine phase majorant."""
from exact_count_core_v5 import F,need,exp_lower,up

def centered_tail(M,rate,delta,ul,uh):
    need(M>=1 and rate>0 and ul<=uh<delta,'centered exponential tail domain')
    A=M-1;xl=rate*(delta-uh);xh=rate*(delta-ul)
    hl=max(exp_lower(xl)-1-xl,xl*xl/2)
    hh=max(exp_lower(xh)-1-xh,xh*xh/2)
    # (exp(x)-1)/h(x)^2 = 1/h(x)+x/h(x)^2 decreases in h>0.
    slope=rate*A*(1/hl+xl/(hl*hl))
    return up(A/hl),up(A/hh),up(slope)
