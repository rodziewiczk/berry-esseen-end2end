"""Discovery-only exact integer evaluation of the two-binomial cubic bound.

The ordinary Fraction implementation remains the acceptance authority.
No probability or phase value is rounded here.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import comb, lcm

@lru_cache(maxsize=1000)
def group(m, B, v):
    assert type(m) is int and m >= 0 and type(B) is F and type(v) is F
    assert B >= 0 and v >= 0
    if m == 0 or B == 0 or v == 0:
        return 1, 0, 0, 1, (1,)
    p = v / (B * B + v)
    base, step = -m * v / B, B + v / B
    den = lcm(base.denominator, step.denominator)
    a = base.numerator * (den // base.denominator)
    b = step.numerator * (den // step.denominator)
    weights = tuple(comb(m, r) * p.numerator ** r *
                    (p.denominator - p.numerator) ** (m-r)
                    for r in range(m+1))
    wd = p.denominator ** m
    assert sum(weights) == wd
    return den, a, b, wd, weights

@lru_cache(maxsize=1000)
def joint(n, j, B0, v0, B1, v1):
    assert type(n) is int and type(j) is int and 0 <= j <= n
    d0, a0, b0, w0, weights0 = group(n-j, B0, v0)
    d1, a1, b1, w1, weights1 = group(j, B1, v1)
    d = lcm(d0, d1)
    base = a0 * (d // d0) + a1 * (d // d1)
    s0, s1 = b0 * (d // d0), b1 * (d // d1)
    atoms = tuple((base+r*s0+s*s1, x*y)
                  for r, x in enumerate(weights0)
                  for s, y in enumerate(weights1))
    return d, w0*w1, atoms

def endpoint(law, distance, tau):
    assert type(distance) is F and type(tau) is F and distance > 0 and tau > 0
    d, wd, atoms = law
    base, step = 1-tau*distance, tau/d
    den = lcm(base.denominator, step.denominator)
    a = base.numerator * (den // base.denominator)
    b = step.numerator * (den // step.denominator)
    total = 0
    for x, w in atoms:
        z = a+b*x
        if z > 0:
            total += w*z*z*z
    return F(total, wd*den**3)

def envelope(n, j, k, ul, uh, s0h, s1h, O0, a1):
    assert type(n) is int and type(j) is int and type(k) is int
    assert all(type(x) is F for x in (ul, uh, s0h, s1h, O0, a1))
    assert 1 <= j-k <= 2 and ul <= uh and F(j-k)-uh > 0
    law = joint(n, j, O0, s0h, a1, s1h)
    tau = F(4, 5) if j == k+1 else F(11, 10)
    right = endpoint(law, F(j-k)-uh, tau)
    left = endpoint(law, F(j-k)-ul, tau)
    slope = (right-left)/(uh-ul) if uh > ul else F(0)
    assert right >= left and slope >= 0
    return right, left, slope, tau, len({x for x, w in law[2]})
