"""Unintegrated exact affine tangent bounds for the sharp one-sided MGF."""
from exact_count_core_v5 import F,need,up,exp_lower,exp_upper,lru_cache,maximum_mgf

@lru_cache(None)
def tangent_coefficients(ceiling,rate,pivot):
    need(ceiling>=0 and rate>=0 and pivot>=0,'tangent MGF domain')
    if ceiling==0:
        need(pivot==0,'zero ceiling pivot');return F(1),F(0)
    if rate==0:return F(1),F(0)
    b2=ceiling*ceiling;den=b2+pivot;v=rate*pivot/ceiling
    need(rate*ceiling<50,'tangent positive exponential domain')
    pos=exp_upper(rate*ceiling)
    neg_hi=1/exp_lower(v);neg_lo=1/exp_upper(v)if v<50 else F(0)
    intercept=up((b2*neg_hi*(b2+2*pivot+v*den)+pivot*pivot*pos)/(den*den))
    slope=up(b2*(pos-neg_lo*(1+rate*den/ceiling))/(den*den))
    need(intercept>=1 and slope>=0,'positive tangent majorant')
    return intercept,slope

@lru_cache(None)
def coupled_tangent_product(n,j,pl,pu,hi,al,ah,s0_hi,s1_hi,O0,a1,rate):
    need(type(n)is int and n>=1 and 0<=j<=n,'count domain')
    need(0<pl<=pu<1 and hi>=0 and 0<=al<=ah<=1,'allocation domain')
    c0=hi/(n*(1-pu));c1=hi/(n*pl);mid=(al+ah)/2
    if O0==0:need(s0_hi==0,'zero first ceiling requires zero variance')
    if a1==0:need(s1_hi==0,'zero second ceiling requires zero variance')
    m0=min(s0_hi,c0*(1-mid))
    m1=min(s1_hi,c1*mid)
    A0,D0=tangent_coefficients(O0,rate,m0)
    A1,D1=tangent_coefficients(a1,rate,m1)
    return up(A0**(n-j)*A1**j*maximum_mgf(n,j,c0*D0/A0,c1*D1/A1,al,ah))
