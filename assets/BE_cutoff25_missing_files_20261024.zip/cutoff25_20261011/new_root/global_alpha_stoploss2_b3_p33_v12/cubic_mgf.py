"""Unintegrated cubic-Hermite exponential majorant with directed coefficients."""
from exact_count_core_v5 import F,need,up,down,exp_lower,exp_upper,lru_cache

@lru_cache(None)
def coefficients(L,B,t):
    need(L>0 and B>0 and t>=0 and t*B<50,'cubic exponential domain')
    if t==0:return F(0),F(0),F(0),F(0)
    negative_hi=1/exp_lower(t*L)
    negative_lo=1/exp_upper(t*L)if t*L<50 else F(0)
    rAl=max(F(0),(negative_lo-1+t*L)/(L*L))
    rAh=(negative_hi-1+t*L)/(L*L)
    rBl=max(F(0),(exp_lower(t*B)-1-t*B)/(B*B))
    rBh=(exp_upper(t*B)-1-t*B)/(B*B)
    c2l=down((B*rAl+L*rBl)/(B+L));c2h=up((B*rAh+L*rBh)/(B+L))
    c3l=max(F(0),down((rBl-rAh)/(B+L)))
    c3h=up((rBh-rAl)/(B+L))
    need(0<=c2l<=c2h and 0<=c3l<=c3h,'ordered directed cubic coefficients')
    return c2l,c2h,c3l,c3h

@lru_cache(None)
def mgf_upper(variance_upper,third_upper,L,B,t):
    need(variance_upper>=0 and L>=0 and B>=0 and t>=0,'cubic moment upper domain')
    if L==0 or B==0:
        need(variance_upper==0 and third_upper==0,'zero endpoint centered law');return F(1)
    c2l,c2h,c3l,c3h=coefficients(L,B,t)
    upper=up(1+c2h*variance_upper+(c3h if third_upper>=0 else c3l)*third_upper)
    # Any feasible centered law has MGF>=1. The clamp is conservative even
    # when this relaxed moment combination does not correspond to a law.
    return max(F(1),upper)

def independent_cubic_product(n,j,s0_hi,s1_hi,a0,O0,O1,a1,t,cubic0_lower,cubic1_lower):
    first=mgf_upper(s0_hi,-cubic0_lower,a0,O0,t)
    second=mgf_upper(s1_hi,-cubic1_lower,O1,a1,t)
    return up(first**(n-j)*second**j)
