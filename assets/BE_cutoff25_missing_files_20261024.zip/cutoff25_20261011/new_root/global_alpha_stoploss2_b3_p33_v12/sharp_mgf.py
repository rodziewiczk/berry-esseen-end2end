"""Sharp one-sided MGF upper enclosure; see SHARP_MGF_PROOF_V1.txt."""
from exact_count_core_v5 import F,need,up,exp_lower,exp_upper,lru_cache
@lru_cache(None)
def sharp_mgf_upper(variance, ceiling, rate):
 need(variance>=0 and ceiling>=0 and rate>=0,'sharp mgf nonnegative domain')
 if ceiling==0:
  need(variance==0,'zero upper endpoint forces zero variance');return F(1)
 if variance==0 or rate==0:return F(1)
 need(rate*ceiling<50,'sharp mgf directed positive exponential range')
 return up((ceiling*ceiling/exp_lower(rate*variance/ceiling)+variance*exp_upper(rate*ceiling))/(ceiling*ceiling+variance))

