"""General positive-side quartic own-loss shape; fixed rational production candidate."""
from functools import lru_cache
from exact_count_core_v5 import F,I,need,intersect
from joint_cubic_normalized_fast import bernstein_upper_vector

MENU=(F(171,235),)

@lru_cache(None)
def maximum_upper(gamma):
    need(gamma==F(171,235),'fixed peak9/20 rational quartic')
    return F(1975509,7520000)

def score_forms_gamma(k,n,t,s0,s1,O0,O1,a0,a1,V,intercept,drift,mass,aa,gamma):
    need(type(n)is int and type(k)is int and n>=1 and 0<=k<=n,
         'actual nonnegative integer counts')
    need(0<=mass<=1 and aa>0 and gamma>0,'quartic scale/shape and mass')
    m=n-k;V=intersect(V,m*s0+k*s1);J=m*s0**2+k*s1**2
    cost=m*O0*a0*s0+k*a1*O1*s1
    B=(gamma-2)*aa;C=(2*gamma-1)*aa*aa;D=gamma*aa**3
    vertex=max(V.l,min(V.h,C/6))
    concave=I(min(C*x-3*x*x for x in(V.l,V.h)),C*vertex-3*vertex*vertex)
    co=[concave+3*J-cost,-3*B*V-D,C-6*V,I(-B),I(-1)]
    scale=mass/(maximum_upper(gamma)*aa**4)
    score=[-scale*x for x in co];score[0]=score[0]+intercept;score[1]=score[1]+drift
    base=bernstein_upper_vector(score,t.l,t.h);out=[]
    for i,value in enumerate(base):
        phase=t.l+F(i,4)*(t.h-t.l)
        out.append((value,scale*m*(a0-O0-B-4*phase),scale*k*(O1-a1-B-4*phase)))
    return out
