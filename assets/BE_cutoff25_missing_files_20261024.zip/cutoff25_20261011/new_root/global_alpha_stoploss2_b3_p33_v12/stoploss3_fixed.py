"""Exact stoploss3 endpoints at two fixed rational tau values."""
from fractions import Fraction as F
from math import comb
from functools import lru_cache

def binomial_comparison(m,B,v):
    assert type(m)is int and m>=0 and B>=0 and v>=0
    if m==0 or B==0 or v==0:return {F(0):F(1)}
    p=v/(B*B+v);q=1-p;low=-v/B;step=B+v/B
    return {m*low+j*step:F(comb(m,j))*p**j*q**(m-j)for j in range(m+1)}

@lru_cache(maxsize=1000)
def comparison_sum(n,j,B0,v0,B1,v1):
    a=binomial_comparison(n-j,B0,v0);b=binomial_comparison(j,B1,v1);out={}
    for x,p in a.items():
        for y,q in b.items():out[x+y]=out.get(x+y,F(0))+p*q
    assert sum(out.values())==1 and sum(x*p for x,p in out.items())==0
    return tuple(sorted(out.items()))

def endpoint(law,d,tau):
    assert d>0 and tau>0
    return sum((p*max(F(0),1+tau*(x-d))**3 for x,p in law),F(0))

def envelope(n,j,k,ul,uh,s0h,s1h,O0,a1):
    assert 1<=j-k<=2 and ul<=uh and F(j-k)-uh>0
    law=comparison_sum(n,j,O0,s0h,a1,s1h)
    dr=F(j-k)-uh;dl=F(j-k)-ul;tau=F(4,5) if j==k+1 else F(11,10)
    right=endpoint(law,dr,tau);left=endpoint(law,dl,tau)
    slope=(right-left)/(uh-ul)if uh>ul else F(0)
    assert right>=left and slope>=0
    return right,left,slope,tau,len(law)
