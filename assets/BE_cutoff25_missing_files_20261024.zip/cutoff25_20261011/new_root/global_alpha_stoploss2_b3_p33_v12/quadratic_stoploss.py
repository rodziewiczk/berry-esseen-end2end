"""Exact integer quadratic stoploss and its optimal positive parameter.

Diagnostic only until a separately named production source imports this.
The input law uses one common atom and weight denominator, as in the
independently reviewed integer two-binomial comparison helper.
"""
from fractions import Fraction as F
from math import lcm

def optimal_tau(law, distance):
    """Minimize sum w[1+tau*(x-distance)]_+^2 exactly over tau>=0."""
    assert type(distance) is F and distance > 0
    atom_den, weight_den, atoms = law
    assert atom_den > 0 and weight_den > 0
    assert all(type(x)is int and type(w)is int and w>0 for x,w in atoms)
    assert sum(w for x,w in atoms)==weight_den
    assert sum(x*w for x,w in atoms)==0
    offset_den=atom_den*distance.denominator
    offsets=[(x*distance.denominator-distance.numerator*atom_den,w)for x,w in atoms]
    S1=sum(a*w for a,w in offsets)
    S2=sum(a*a*w for a,w in offsets)
    assert S1<0 and S2>0
    negative={}
    for a,w in offsets:
        if a<0:negative[a]=negative.get(a,0)+w
    left=F(0)
    # With s=tau/offset_den, negative atom a leaves at s=-1/a.
    # Sorting a increasingly sorts those breakpoints increasingly.
    for a,w in sorted(negative.items()):
        right=F(-1,a)
        assert right>left and S2>=0
        if S2==0:
            assert S1==0 and left>0
            return offset_den*left
        stationary=F(-S1,S2)
        assert stationary>=left
        if stationary<=right:
            assert stationary>0
            return offset_den*stationary
        S1-=a*w;S2-=a*a*w
        left=right
    # If no earlier stationary point exists, all nonzero offsets vanished.
    assert left>0 and S1==S2==0
    return offset_den*left

def endpoint(law,distance,tau):
    assert type(distance)is F and type(tau)is F and distance>0 and tau>0
    atom_den,weight_den,atoms=law
    base,step=1-tau*distance,tau/atom_den
    den=lcm(base.denominator,step.denominator)
    a=base.numerator*(den//base.denominator)
    b=step.numerator*(den//step.denominator)
    total=0
    for x,w in atoms:
        z=a+b*x
        if z>0:total+=w*z*z
    return F(total,weight_den*den*den)

def law_envelope(law,left_distance,right_distance):
    assert type(left_distance)is F and type(right_distance)is F
    assert left_distance>=right_distance>0
    tau=optimal_tau(law,right_distance)
    right=endpoint(law,right_distance,tau)
    left=endpoint(law,left_distance,tau)
    width=left_distance-right_distance
    slope=(right-left)/width if width else F(0)
    assert 0<=left<=right<=1 and slope>=0
    return right,left,slope,tau
