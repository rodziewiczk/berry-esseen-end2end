"""Fixed positive shift of the exponential tangent; diagnostic only."""
from exact_count_core_v5 import F,need,exp_lower,exp_upper,up

def shifted_centered_tail(M,rate,delta,ul,uh,eta):
    need(M>=1 and rate>0 and ul<=uh<delta and 0<=eta<50,
         'shifted centered exponential tail domain')
    N=exp_upper(eta)*M-1-eta
    need(N>=0,'nonnegative shifted excess numerator')
    xl=rate*(delta-uh)+eta;xh=rate*(delta-ul)+eta
    hl=max(exp_lower(xl)-1-xl,xl*xl/2)
    hh=max(exp_lower(xh)-1-xh,xh*xh/2)
    slope=rate*N*(1/hl+xl/(hl*hl))
    return up(N/hl),up(N/hh),up(slope)
