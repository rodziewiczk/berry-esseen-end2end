"""Unintegrated marginalwise minimum of two valid exponential bounds."""
from exact_count_core_v5 import up
from cubic_mgf import mgf_upper
from sharp_mgf import sharp_mgf_upper

def independent_mixed_product(n,j,s0_hi,s1_hi,a0,O0,O1,a1,t,cubic0_lower,cubic1_lower):
    first=min(mgf_upper(s0_hi,-cubic0_lower,a0,O0,t),sharp_mgf_upper(s0_hi,O0,t))
    second=min(mgf_upper(s1_hi,-cubic1_lower,O1,a1,t),sharp_mgf_upper(s1_hi,a1,t))
    return up(first**(n-j)*second**j)
