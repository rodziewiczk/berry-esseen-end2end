"""Diagnostic convex common-moment shifted-excess incoming envelope."""
from exact_count_core_v5 import *
from common_cubic_bound import affine_mgf,expo
from joint_cubic_normalized_fast import score_forms

def reciprocal_chord(rate,delta,ul,uh,eta):
    need(rate>0 and ul<=uh<delta and eta>=0,'positive shifted distances')
    xleft=rate*(delta-ul)+eta;xright=rate*(delta-uh)+eta
    dl=max(exp_lower(xleft)-1-xleft,xleft*xleft/2)
    dr=max(exp_lower(xright)-1-xright,xright*xright/2)
    return tuple((1-F(i,4))/dl+F(i,4)/dr for i in range(5))

def bound(k,n,t,s0,s1,O0,O1,a0,a1,V,intercept,drift,mass,vertices,incoming_context):
    args,values=incoming_context
    nn,kk,pl,pu,lo,hi,al,ah,ul,uh,ss0,ss1,o0,aa1=args
    need(nn==n and kk==k and ul==t.l and uh==t.h and ss0.l==s0.l and ss0.h==s0.h and ss1.l==s1.l and ss1.h==s1.h and o0==O0 and aa1==a1,'same cell incoming context')
    incoming,left,lip,gaussian=values
    need(drift==lip-gaussian,'same frozen original Gaussian/incoming envelope')
    base_intercept=intercept-left+lip*ul;base_drift=-gaussian
    ms=masses(n,pl,pu)
    cx=sum((x for x,y,r in vertices),F(0))/len(vertices)
    cy=sum((y for x,y,r in vertices),F(0))/len(vertices)
    mx=max(abs(x)for x,y,r in vertices);my=max(abs(y)for x,y,r in vertices)
    rates=[]
    for rate in (F(2),F(3),F(4),F(6),F(8)):
        if max(rate*O0,rate*a1)>=50:continue
        A0,D0=affine_mgf(s0.h,a0,O0,rate,mx)
        A1,D1=affine_mgf(s1.h,O1,a1,rate,my)
        pivot0=up(max(F(1),A0-D0*cx));pivot1=up(max(F(1),A1-D1*cy))
        rates.append((rate,A0,D0,A1,D1,pivot0,pivot1))
    additions=[[F(0)]*5 for _ in vertices];chosen=[]
    for j in range(k+1,n+1):
        variance=(n-j)*s0.h+j*s1.h;distance=F(j-k)-uh
        constant=variance/(variance+distance*distance)
        candidates=[(constant,None)]
        for data in rates:
            rate,A0,D0,A1,D1,pivot0,pivot1=data
            pivot_product=pivot0**(n-j)*pivot1**j
            oldphases=tuple(((1-F(i,4))*expo(rate*ul)+F(i,4)*expo(rate*uh))/exp_lower(rate*(j-k))for i in range(5))
            candidates.append((pivot_product*oldphases[2],(data,None,oldphases)))
            for eta in (F(0),F(1,4),F(1,2),F(1),F(2)):
                phases=reciprocal_chord(rate,F(j-k),ul,uh,eta)
                at_center=max(F(0),exp_upper(eta)*pivot_product-1-eta)
                candidates.append((at_center*phases[2],(data,eta,phases)))
        _,selected=min(candidates,key=lambda z:z[0])
        if selected is None:
            chosen.append('cantelli')
            for row in additions:
                for i in range(5):row[i]=up(row[i]+ms[j][1]*constant)
            continue
        data,eta,phases=selected
        rate,A0,D0,A1,D1,pivot0,pivot1=data
        chosen.append(dict(rate=str(rate),eta=None if eta is None else str(eta)))
        scale=pivot0**(n-j)*pivot1**j
        for row,(x,y,rho)in zip(additions,vertices):
            q0=max(F(1),A0-D0*x);q1=max(F(1),A1-D1*y)
            average=F(n-j,n)*q0/pivot0+F(j,n)*q1/pivot1
            G=up(scale*average**n)
            numerator=G if eta is None else max(F(0),exp_upper(eta)*G-1-eta)
            for i in range(5):row[i]=up(row[i]+ms[j][1]*numerator*phases[i])
    sn=root(F(n),10**12)[1];best=None
    for aa in (F(i,20)for i in range(2,25)):
        forms=score_forms(k,n,t,s0,s1,O0,O1,a0,a1,V,base_intercept,base_drift,mass,aa)
        value=max(up(sn*max(F(0),max(B+xx*x+yy*y+extra for(B,xx,yy),extra in zip(forms,row)))/rho)for(x,y,rho),row in zip(vertices,additions))
        best=value if best is None else min(best,value)
    return best,chosen
