"""Unintegrated common-cubic/AM-GM incoming bound; research diagnostic only."""
from exact_count_core_v5 import *
from cubic_mgf import coefficients
from joint_cubic_normalized_fast import score_forms

def affine_mgf(sup,L,B,t,moment_abs):
    need(sup>=0 and L>=0 and B>=0 and moment_abs>=0,'cubic affine domain')
    if L==0 or B==0:
        need(sup==0 and moment_abs==0,'zero conditional marginal');return F(1),F(0)
    _,c2u,c3l,c3u=coefficients(L,B,t)
    mid=(c3l+c3u)/2;error=(c3u-c3l)*moment_abs/2
    return up(1+c2u*sup+error),mid

def expo(x):
    return exp_upper(x)if x>=0 else 1/exp_lower(-x)

def bound(k,n,t,s0,s1,O0,O1,a0,a1,V,intercept,drift,mass,vertices,incoming_context):
    """Return normalized score; all fixed choices are made before vertex maxima.

    vertices split the common cubic polygon along the affine rho-floor seam.
    Each convex numerator divided by that positive affine floor attains its
    maximum at a vertex of each piece. No product-law feasibility is asserted
    for those relaxed vertices.
    """
    args,values=incoming_context
    nn,kk,pl,pu,lo,hi,al,ah,ul,uh,ss0,ss1,o0,aa1=args
    need(nn==n and kk==k and ul==t.l and uh==t.h and ss0.l==s0.l and ss0.h==s0.h and ss1.l==s1.l and ss1.h==s1.h and o0==O0 and aa1==a1,'same cell incoming context')
    incoming,left,lip,gaussian=values
    need(drift==lip-gaussian,'same frozen original Gaussian/incoming envelope')
    base_intercept=intercept-left+lip*ul
    base_drift=-gaussian
    ms=masses(n,pl,pu)
    cx=sum((x for x,y,r in vertices),F(0))/len(vertices)
    cy=sum((y for x,y,r in vertices),F(0))/len(vertices)
    mx=max(abs(x)for x,y,r in vertices);my=max(abs(y)for x,y,r in vertices)
    rates=[]
    for rate in (F(2),F(3),F(4),F(6),F(8)):
        if max(rate*O0,rate*a1)>=50:continue
        A0,D0=affine_mgf(s0.h,a0,O0,rate,mx)
        A1,D1=affine_mgf(s1.h,O1,a1,rate,my)
        pivot0=up(max(F(1),A0-D0*cx));pivot1=up(max(F(1),A1-D1*cy))
        phases=[(1-F(i,4))*expo(rate*ul)+F(i,4)*expo(rate*uh)for i in range(5)]
        rates.append((rate,A0,D0,A1,D1,pivot0,pivot1,phases))
    additions=[[F(0)]*5 for _ in vertices]
    chosen=[]
    for j in range(k+1,n+1):
        # Frozen right-endpoint Cantelli is a convex constant alternative.
        variance=(n-j)*s0.h+j*s1.h;distance=F(j-k)-uh
        constant=variance/(variance+distance*distance)
        candidates=[(constant,None)]
        for data in rates:
            rate,A0,D0,A1,D1,pivot0,pivot1,phases=data
            at_center=pivot0**(n-j)*pivot1**j/exp_lower(rate*(j-k))
            candidates.append((at_center*phases[2],data))
        _,selected=min(candidates,key=lambda z:z[0])
        chosen.append('cantelli'if selected is None else str(selected[0]))
        if selected is None:
            for row in additions:
                for i in range(5):row[i]=up(row[i]+ms[j][1]*constant)
            continue
        rate,A0,D0,A1,D1,pivot0,pivot1,phases=selected
        scale=ms[j][1]*pivot0**(n-j)*pivot1**j/exp_lower(rate*(j-k))
        for row,(x,y,rho)in zip(additions,vertices):
            q0=max(F(1),A0-D0*x);q1=max(F(1),A1-D1*y)
            average=F(n-j,n)*q0/pivot0+F(j,n)*q1/pivot1
            product=up(scale*average**n)
            for i in range(5):row[i]=up(row[i]+product*phases[i])
    sn=root(F(n),10**12)[1];best=None
    for aa in(F(i,20)for i in range(2,25)):
        forms=score_forms(k,n,t,s0,s1,O0,O1,a0,a1,V,base_intercept,base_drift,mass,aa)
        value=max(up(sn*max(F(0),max(B+xx*x+yy*y+extra for(B,xx,yy),extra in zip(forms,row)))/rho)for(x,y,rho),row in zip(vertices,additions))
        best=value if best is None else min(best,value)
    return best,chosen
